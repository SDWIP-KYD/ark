# REFERAT KASUS KLINIS

## DATA PASIEN
- **Nama:** Muhammad Nur Irsyam
- **No. RM:** 271356
- **Usia:** 1 bulan (lahir 20-6-2026)
- **Jenis kelamin:** Laki-laki
- **Ruang:** PICU Bed 5 RSUH
- **Tanggal pengkajian:** 11 Agustus 2026

---

## I. IDENTITAS & ANAMNESIS

### Subjektif
Anak laki-laki usia 1 bulan dikonsul dari divisi ETIA dengan masalah **pemanjangan faal hemostasis** + **post status epileptikus et causa subdural hemorrhage acute on chronic** regio frontotemporoparieto-occipital kiris.

**Keluhan utama saat masuk:** tidak kejang, tidak demam, tidak batuk/sesak, tidak muntah. Minum ASI via NGT. BAK kuning jernih, BAB kuning biasa.

**Riwayat kehamilan:** Kehamilan ke-3, kontrol rutin di Puskesmas & Bidan. Rutin vitamin. Hipertensi, DM, asma, ISK disangkal. Jamu disangkal.

**Riwayat kelahiran:** Persalinan normal di Puskesmas dibantu bidan, cukup bulan, menangis segera, BBL 2600 g. APGAR tidak diketahui. **Riwayat injeksi Vit K dilaporkan ada** (tanpa dokumentasi dosis/waktu).

**Riwayat menyusu:** ASI eksklusif sejak lahir.

**Riwayat imunisasi:** HepB0 1x.

**Riwayat penyakit:** sering demam (-), sering pucat (-), transfusi PRC (+), mimisan/gusi berdarah/BAB hitam/BAK merah (-), bengkak sendi (-), kemerahan sendi (-), **turun berat badan (+)**, keganasan keluarga (-), tinggal dekat persawahan (+).

- **Riwayat kejang pertama kali ada dirumah 1x pada 8 Agustus 2026**, durasi 1 jam, **fokal** (hentakan tangan & kaki kanan + mata mendelik kanan), **didahului demam**, setelah kejang menangis. Kejang tanpa demam (-).
- **Riwayat trauma kepala (-), anak sering diayun (+), kejang keluarga (-), epilepsi (-), lebam sejak lahir (-).**
- **Riwayat keluarga kunci:** kakak laki-laki pasien **meninggal tiba-tiba setelah kejang 1x disertai mimisan berulang**.
- Batuk >2 minggu (+), paparan rokok ayah (+), kontak TB (-). Muntah 1x pasca-kejang (susu+lendir, tak menyemprot).

**Riwayat rawat:** RS Jeneponto 8–11 Agustus 2026, dx post bangkitan kejang et causa epilepsi + suspek perdarahan intrakranial + anemia. Terapi: cefotaxime, gentamicin, phenobarbital loading 10 mg/kgBB + maintenance 8, dobutamin 3 mcg/kgBB/menit, metilprednisolon 2 mg/kgBB, paracetamol, transfusi PRC 90 mL.

---

## II. PEMERIKSAAN FISIK

### TTV & Status Umum
- KU: sakit berat / gizi baik / **GCS 15 (E4M6V5)**
- TD: 76/33 mmHg | Nadi: 110x/menit | Napas: 30x/menit | Suhu: 36,5°C | SpO2: 99% RA
- BB 4 kg | PB 54 cm | LK 37 cm (normal) | LILA 11 cm

### Antropometri
BB/U, PB/U, BB/PB: antara median –1 SD (gizi baik, perawakan normal).

### Status Neurologis
Kesadaran GCS 15. NC II–XII: pupil isokor 2/2 mm, refleks cahaya +, okulomotor normal, kornea +, facialis simetris, menelan +, lidah sentral. Motorik ekstremitas 5555/5555, tonus normal, refleks fisiologis +, patologis (Babinski/Oppenheim/Chaddock/Gordon) -.

### Organ Lain
- Ubun-ubun tidak membonjol. Tidak pucat, tidak ikterus.
- Paru: sonor, bronkovesikuler, rhonki/wheezing -.
- Jantung: bunyi I/II murni regular, bising -.
- Abdomen: datar, peristaltik +, hepar/lien tidak teraba, timpani.
- Ekstremitas: akral hangat, CRT <3 detik, edema -.

### Skor
- **Phoenix score:** 2 (Koagulasi 2, sisanya 0).
- **DIC score (ISTH):** Trombosit 0, D-dimer 2, PTT 2, Fibrinogen belum diperiksa → **belum lengkap, tidak memenuhi DIC**.

---

## III. HASIL LABORATORIUM & PENUNJANG

### Laboratorium RS Lanto Dg Pasewang 09-08-2026
| Parameter | Hasil | Referensi |
|---|---|---|
| HB | 5,1 g/dL | ↓ |
| MCV | 87,4 fL | normal |
| WBC | 19.880/µL | ↑ |
| PLT | 508.000/µL | ↑ |
| GDS | 152 mg/dL | ↑ |

### Laboratorium RS Lanto Dg Pasewang 10-08-2026
| Parameter | Hasil | Referensi |
|---|---|---|
| HB | 14,2 g/dL | (pasca-transfusi) |
| MCV | 86,7 fL | normal |
| WBC | 12.790/µL | ↑ |
| PLT | 500.000/µL | ↑ |
| Na/K/Cl | 133/4,7/100 | Na ↓ |
| Kreatinin | 0,78 mg/dL | ↑ (2x baseline) |
| LFG | 31,15 | ↓ 53% |
| CRP | 3,2 mg/dL | ↑ ringan |
| SGOT/SGPT | 24/13 | normal |

### Laboratorium RSUH 13/8/2026 (KONFIRMASI)
| Parameter | Hasil | Referensi |
|---|---|---|
| **PT** | **12,4 detik** | 10–13,6 |
| **aPTT** | **32,3 detik** | 26,9–62,5 |
| **INR** | **0,89** | <1,2 |

> **Konfirmasi diagnosis:** INR 7,06 (11/8) → 0,89 (13/8) dalam 2 hari pasca-Vit K 1 mg IM = **respons dramatis terhadap Vitamin K → MEMBUKTIKAN Late VKDB**. Defisiensi faktor kongenital (FXIII/hemofilia) TIDAK akan merespons Vit K. Hipotesis congenital bleeding disorder **terbantahkan**, namun riwayat keluarga (kakak meninggal + mimisan) tetap perlu ditelusuri untuk skrining carrier.

### CT Scan Kepala Non-Kontras RSUH 17/8/2026 (KONTROL)
- Lesi hiperdense (65 HU) estimasi **volume ~14 cc** + lesi hipodense (18 HU) regio frontotemporoparieto-occipital kiri & falx cerebri.
- Midline shift **0,5 cm** (sebelumnya 0,98 cm 11/8) → menyempit.
- Sulci & gyri normal (edema serebral **reda**), ventrikel & sirkumserebral lain normal.
- Kesan: **St. Quo Ante** (stabil, perbaikan dibanding 11/8).
- **Thorax 10-08:** dalam batas normal.
- **USG kepala 10-08:** ventrikel normal, **lesi hiperdens cerebri → suspek intracerebral hematom**.
- **CT scan kepala non-kontras RSUH 11-08:** **Subdural hemorrhage acute on chronic** regio frontotemporoparieto-occipital kiri + falx cerebri, menyempitkan ventrikel lateralis kiri, **midline shift ~0,98 cm**, sulci/gyri obliterasi, **brain edema**.

---

## IV. ASSESSMENT (REVISI)

### Diagnosis Utama
1. **Hemorrhagic Disease of the Newborn / Vitamin K Deficiency Bleeding (Late VKDB) — TERKONFIRMASI.**
   - Dasar: INR 7,06 (11/8) → 0,89 (13/8) pasca-Vit K 1 mg IM = respons dramatis → diagnosis terbukti. SDH acute on chronic di umur 1 bulan + ASI eksklusif (Vit K rendah) + profilaksis dilaporkan "ada" namun efek menurun bulan ke-2.
   - Riwayat keluarga (kakak meninggal + mimisan) sempat mengarahkan ke congenital, tetapi **terbantahkan oleh respons Vit K**. Tetap skrining carrier keluarga untuk kelengkapan.
2. **Subdural hemorrhage acute on chronic regio frontotemporoparieto-occipital kiri** dengan midline shift 0,5 cm (menyempit dari 0,98 cm) dan brain edema (reda). Volume ~14 cc.
   - Komponen "chronic" + "anak sering diayun" + usia 1 bulan → catat pertimbangan AHT, namun etiologi utama adalah VKDB. Lapor child protection bila ada keraguan.
3. **Post status epileptikus (resolved)** — bebas kejang H-5.
4. **Anemia pasca perdarahan akut** — MCV normositik 86-87 fL, HB recovery pasca-transfusi PRC 90 mL.
5. **Acute Kidney Injury KDIGO Stage 2 → recovering** — kreatinin turun, UO adekuat 3,5 ml/kg/jam, TD recover 99/51.
6. **Poliuria (UO 3,5 ml/kg/jam, BC -11,3 ml/kgBB)** — perlu workup Na/osmol urin vs serum (curiga DI / NDI pasca-AKI atau efek steroid).
7. **Suspect sepsis / SIRS (resolving)** — leukositosis + trombositosis reaktif + CRP ringan.
8. **Hiponatremia (Na 133) → resolving** — SIADH sekunder cedera otak, pantau Na.
9. **Leukositosis & trombositosis reaktif** — respons inflamasi.

### Diagnosis Banding Hemostasis
- **DIC:** DITOLAK — PLT tidak turun, fibrinogen normal-range, pola PT/INR memanjang yang **responsif Vit K** khas defisiensi Vit K murni.
- **Congenital factor deficiency (FXIII/hemofilia):** DITOLAK oleh respons INR → normal dalam 48j pasca-Vit K.
- **Liver disease:** SGOT/SGPT normal.
- **Idiopathic neonatal seizure:** sekunder terhadap SDH.

---

## V. RENCANA & TERAPI (REVISI)

### Prioritas
1. **Lanjutkan Vit K** — meski INR normal, pastikan regimen lengkap (catat alasan "tunda" di laporan perlu klarifikasi; idealnya 1 mg IM berturut-turut hingga profilaksis lengkap tercapai).
2. **Workup poliuria** — Na/osmol urin vs serum, cek ulang Na/K/Cl, pantau balance cairan (BC -11,3). Curiga DI/NDI pasca-AKI atau efek dexametason.
3. **Neuroimaging follow-up** — CT kontrol terjadwal (sudah St.Quo Ante, lanjutkan tanpa dekompresi). Konsul bedah saraf bila shift memburuk.
4. **Monitoring neurologis & developmental** — risiko sekuela SDH (hidrosefalus, mikrosefali, retardation). Jadwal follow-up poli/neurosensorik.
5. **Nutrisi** — ASI/SF 8x50 mL via NGT + parenteral perconnecta. Pastikan target kalori 516 kkal tercapai.
6. **AKI recovery** — pantau UO, kreatinin, elektrolit. Stop gentamicin (nefrotoksik).
7. **Suspect sepsis resolving** — kultur darah/LCS jika belum, cefotaxime dilanjut sambil menunggu.
8. **Skrining carrier keluarga** — telusuri kematian kakak (usia, mimisan berulang, perdarahan lain) untuk rule-out hereditary (meski VKDB sudah terbukti pada pasien ini).
9. **Child protection** — dokumentasikan "anak sering diayun" + SDH chronic; laporkan bila ada keraguan etiologi.
10. **Edukasi orang tua** — tanda perdarahan ulang, kejang, fontanel membonjol; pentingnya profilaksis Vit K untuk adik/keluarga.

---

## V-B. PROGRESS & RESOLUSI KLINIS (update 17/8/2026)

| Parameter | Masuk (11/8) | Kontrol (17/8) | Interpretasi |
|---|---|---|---|
| INR | 7,06 | 0,89 | ✅ Normal — VKDB teratasi |
| Midline shift | 0,98 cm | 0,5 cm | ✅ Menyempit |
| Brain edema | Ada (sulci obliterasi) | Reda (sulci/gyri normal) | ✅ Membaik |
| TD | 76/33 | 99/51 | ✅ Perfusi recover |
| Kejang | Aktif (status epi) | Bebas H-5 | ✅ Resolved |
| UO | - | 3,5 ml/kg/jam | ✅ Adekuat (AKI recovering) |
| BC | - | -11,3 ml/kgBB | ⚠️ Negative balance → poliuria perlu workup |
| Volume SDH | - | ~14 cc | ⚠️ Stabil, konservatif |

**Kesimpulan trajectory:** Kasus mengalami perbaikan bertahap. Diagnosis VKDB terkonfirmasi oleh normalisasi INR pasca-Vit K. Tidak ada indikasi dekompresi bedah (midline shift mengecil, edema reda). Fokus saat ini: resolusi poliuria, nutrisi, dan follow-up neurologis jangka panjang (risiko seqeula SDH).

---

## VI. DISKUSI SINGKAT — HDN / VKDB

Hemorrhagic Disease of the Newborn terjadi akibat defisiensi Vitamin K → gangguan sintesis faktor pembekuan dependent Vitamin K (**II, VII, IX, X** + protein C/S). Vitamin K minimal di ASI, plasenta buruk menembusnya, kolon neonatus steril (belum memproduksi K2).

**Klasifikasi:**
- **Early (0–24 j):** ibu dapet antikonvulsan/antituberkulosis/Warfarin.
- **Classical (1–7 j):** perdarahan tali pusat, GI, kulit.
- **Late (2–12 mg, puncak 3–8 mg):** **paling fatal** — perdarahan intrakranial (SDH/ICH), tanpa profilaksis atau ASI eksklusif + profilaksis tak adekuat.

**Diagnosis:** PT/INR memanjang mencolok (faktor VII寿命最短), aPTT memanjang, PLT & fibrinogen normal. PTT/konfirmasi level Vit K epoxide (biasanya tak perlu).

**Tata laksana:** Vit K 1 mg IM/IV; jika perdarahan masif → transfusi FFP/kriopresipitat; koreksi anemia; neurosurgery bila mass effect. **Profilaksis:** Vit K 1 mg IM sekali lahir menurunkan late VKDB >90%.

**Poin kasus ini:** Late VKDB bisa terjadi walau dilaporkan dapat 1x IM Vit K — efikasi menurun setelah 2–4 minggu, dan ASI eksklusif rentan. Investigasi dokumentasi esensial.

---

*Referat disusun untuk keperluan pendidikan klinis — bukan pengganti penilaian langsung.*

*Catatan kompilasi: dokumen ini menggabungkan 2 laporan (laporan awal masuk RSUH dari RS Lanto Dg Pasewang, dan laporan tindak-lanjut RSUH 11/8). Data kunci dari laporan awal (riwayat keluarga kakak meninggal + mimisan, batuk >2mg, paparan rokok, "anak sering diayun") tidak tampak di laporan ke-2 dan diintegrasikan di sini.*
