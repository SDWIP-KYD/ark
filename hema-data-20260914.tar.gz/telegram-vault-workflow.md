---
title: "Telegram → Vault Download Workflow"
source: "Hermes Agent skill update 2026-07-19"
tags: [workflow, telegram, download, vault, obsidian]
---

# Telegram → Vault Download Workflow

## Source Detection
- Link `t.me/...` → Telegram public channel file
- Link `telepack.ru/app/s/...` → SPA file hosting via Telegram API

## Flow A — t.me Download

### 1. Get CDN URL
```bash
curl -sL -X POST "https://telegramdownloader.net/proxy.php" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "User-Agent: Mozilla/5.0" \
  -d "telegram_link={LINK_TELEGRAM}"
```
Response: `{"success":true,"data":{"data":{"link":"...","file_name":"..."}}}`

### 2. Handle Filename Issues
- **Filename has spaces or `&`** → direct curl to CDN returns 404. Use Playwright:
  - Build lander URL: `https://telegramdownloader.net/download/?file_url={base64(dl_url)}&file_name={base64(file_name)}`
  - Navigate Playwright to lander → page renders URL with DASH (spaces → `-`)
  - Extract href from `a#download-btn` → clean CDN URL
  - curl clean URL (or trigger download via `page.expect_download()`)
- **Filename clean** (underscores, no spaces) → langsung curl URL from API, works.

### 3. Download via Browser
```python
# For problematic filenames
async with page.expect_download(timeout=30000):
    await btn.click()
download = await page.wait_for_download()
await download.save_as(f"/tmp/{name}.pdf")
```

## Flow B — telepack.ru Download

1. Playwright navigate to URL, `wait_until="domcontentloaded"` (NOT networkidle — timeout)
2. Tunggu 5s render
3. Cari button "Download" (match text content == 'Download')
4. Trigger: `async with page.expect_download(timeout=30000): await btn.click()`
5. `download.save_as("/tmp/{name}.pdf")`

## Analysis
```bash
pdftotext "{file}.pdf" -
```
Parse 2000 chars pertama → title, author, year, publisher.
Cari `Copyright © (\d{4})`, `ISBN:\s*([\d-]+)`, pola bulan+tahun buat periodikal.
Pages: `len(re.split(r'\f', text))`

## Vault Storage
Simpan ke `~/Sync/Vault-Kedokteran/{kategori}/`:
- `01-Textbooks/{Subjek}/` — buku teks
- `UPTODATE/{Subjek}/` — UpToDate kompilasi
- `Journals/{Nama Jurnal}/` — periodikal
- `08-Reference-Tables/` — tabel/cheat sheet

Buat 2 file:
- PDF asli
- Markdown note dengan frontmatter (title, source, tags) + analisis konten

## Pitfalls
- **Filename with SPACES** → CDN 404, wajib Playwright lander
- **Filename with `&`** → URL parsing rusak, wajib Playwright
- **404 despite URL correct** → set `Referer: https://telegramdownloader.net/download/`
- **telepack.ru timeout** → pakai `domcontentloaded` bukan `networkidle`
- **Bot API Telegram** → cannot access channel files without being admin
- **telegramdownloader.net API returns spaces** → replace spaces→hyphens in URL path before download
