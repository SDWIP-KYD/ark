# Index Notulensi Konferensi Divisi Pediatri

> Dibuat: 07 August 2026 20:16 WITA  
> Total file: 164

| No | Nama File | Topik Pembahasan | Materi (Weighted) |
|---|---|---|---|
| 1 | 2025 / 10. Notulensi Konfrens Oktober 2025.docx | Multi-kasus (konfrens bulanan) | Nefrologi - Pembahasan Kasus (17%), Kardiologi - Pembahasan Kasus (17%), Respirologi - Pembahasan Kasus (17%), Neurologi - Pembahasan Kasus (17%), Endokrinologi - Pembahasan Kasus (16%), Alergi-Imunologi - Pembahasan Kasus (16%) |
| 2 | 2025 / 10. Oktober 2025 / 1 Okt 2025 Div GEH (Kolestatis).docx | Kolestatis | Kolestasis (100%) |
| 3 | 2025 / 10. Oktober 2025 / 10 Okt 2025 Div Nefro (AKI).docx | AKI | Acute Kidney Injury (AKI) (100%) |
| 4 | 2025 / 10. Oktober 2025 / 13 Okt 2025 Div Neurologi (Involuntary Movement & Skoliosis).docx | Involuntary Movement & Skoliosis | Involuntary Movement (50%), Skoliosis (50%) |
| 5 | 2025 / 10. Oktober 2025 / 15 Okt 2025 Div Nefro (Pyelonefritis akut + Hordeolum Oculi Sinistra).docx | Pyelonefritis akut + Hordeolum Oculi Sinistra | Pyelonefritis (100%) |
| 6 | 2025 / 10. Oktober 2025 / 17 Okt 2025 Div Alergi Imun (Urtikaria Post Anafilaktik).docx | Urtikaria Post Anafilaktik | Urtikaria (50%), Reaksi Anafilaktik (50%) |
| 7 | 2025 / 10. Oktober 2025 / 20 Okt 2025 Div ETIA Endokrin (KAD).docx | KAD | Ketoasidosis Diabetikum (KAD) (100%) |
| 8 | 2025 / 10. Oktober 2025 / 22 Okt 2025 Div Alergi Imun (Selulitis+CAP+Overweight).docx | Selulitis+CAP+Overweight | Pneumonia/CAP (50%), Selulitis (50%) |
| 9 | 2025 / 10. Oktober 2025 / 24 Okt 2025 Div Kardiologi (DORV + Abses serebri).docx | DORV + Abses serebri | Abses Serebri (50%), DORV (50%) |
| 10 | 2025 / 10. Oktober 2025 / 24 Okt 2025 Div Kardiologi (DORV).docx | DORV | DORV (100%) |
| 11 | 2025 / 10. Oktober 2025 / 27 Okt 2025 Div Introp (Sifilis Kongenital).docx | Sifilis Kongenital | Sifilis Kongenital (100%) |
| 12 | 2025 / 10. Oktober 2025 / 29 Oktober 2025 Divisi Endokrinologi Notulensi Konfrens CAH.docx | Endokrinologi | Hiperplasia Adrenal Kongenital (CAH) (100%) |
| 13 | 2025 / 10. Oktober 2025 / 3 Oktober 2025 Notulensi Konfrens Divisi Neonatologi.docx | Neonatologi | Neonatologi - Pembahasan Kasus (100%) |
| 14 | 2025 / 10. Oktober 2025 / 3 Oktober 2025 Notulensi Konfrens Divisi Neurologi.docx | Neurologi | Neurologi - Pembahasan Kasus (100%) |
| 15 | 2025 / 10. Oktober 2025 / 31 Oktober 2025_ KonfrensKlinik Divisi TKPS.docx | TKPS | TKPS - Pembahasan Kasus (100%) |
| 16 | 2025 / 10. Oktober 2025 / 6 Okt 2025 Div Respi (Asma Bronkial).docx | Asma Bronkial | Asma Bronkial (100%) |
| 17 | 2025 / 10. Oktober 2025 / 6 Oktober 2025 Div Respirologi- Asma Bronkhial.docx | Respirologi | Asma Bronkial (100%) |
| 18 | 2025 / 10. Oktober 2025 / 8 Oktober 2025 Notulensi Konfrens Divisi Neonatologi.docx | Neonatologi | Neonatologi - Pembahasan Kasus (100%) |
| 19 | 2025 / 10. Oktober 2025 / Notulensi Konferens, 13-10-2025.docx | Multi-kasus (konfrens bulanan) | Neurologi - Pembahasan Kasus (100%) |
| 20 | 2025 / 11. November 2025 / 10 Nov 2025 Div Respirologi (Efusi Pleura).docx | Efusi Pleura | Efusi Pleura (100%) |
| 21 | 2025 / 11. November 2025 / 12 Nov 2025 Div Introp (Morbili with complication).docx | Morbili with complication | Morbili (Campak) (100%) |
| 22 | 2025 / 11. November 2025 / 14 November 2025 Div Hematoonkologi (Hiperleukositosis) .docx | Hiperleukositosis | Hiperleukositosis (100%) |
| 23 | 2025 / 11. November 2025 / 17 Nov 2025 Div ETIA (Cyanotic Spell + Truncus Arteriosus).docx | Cyanotic Spell + Truncus Arteriosus | ETIA-Emergensi - Pembahasan Kasus (100%) |
| 24 | 2025 / 11. November 2025 / 19 Nov 2025 Div Gastro (Kolestasis Intrahepatik dd Ekstrahepatik).docx | Kolestasis Intrahepatik dd Ekstrahepatik | Kolestasis (100%) |
| 25 | 2025 / 11. November 2025 / 21 Nov 2025 Div Hema (Neuroblastoma).docx | Neuroblastoma | Neuroblastoma (100%) |
| 26 | 2025 / 11. November 2025 / 26 Nov 2025 Div Neonatologi (atresia jejenum DD_ stenosis jejenum) dan NPM (Gizi Buruk tipe Marasmus).docx | atresia jejenum DD_ stenosis jejenum | Gizi Buruk Marasmus (50%), Atresia/Stenosis Jejunum (50%) |
| 27 | 2025 / 11. November 2025 / 28 Nov 2025 Div ETIA (Bee sting).docx | Bee sting | Bee Sting (100%) |
| 28 | 2025 / 11. November 2025 / 3 Nov 2025 Div Neurologi (Encephalopathy Hipertensi) & Div Neo (RDN+ASD+Hipoglikemia).docx | Encephalopathy Hipertensi | Ensefalopati (25%), Respiratory Distress (RDN) (25%), ASD (25%), Hipoglikemia (25%) |
| 29 | 2025 / 11. November 2025 / 5 Nov 2025 Div ETIA (Status Epileptikus) dan Div Neo (Kejang Neonatorum).docx | Status Epileptikus | Epilepsi/Kejang (50%), Status Epileptikus (50%) |
| 30 | 2025 / 11. November 2025 / 7 November 2025 Div Alergi-Imunologi.docx | Alergi-Imunologi | Alergi-Imunologi - Pembahasan Kasus (100%) |
| 31 | 2025 / 12. Desember 2025 / 1 Des 2025 Div Kardio (Kawasaki Disease).docx | Kawasaki Disease | Penyakit Kawasaki (100%) |
| 32 | 2025 / 12. Desember 2025 / 12 Des 2025 Div ETIA (ARDS+KAD).docx | ARDS+KAD | Ketoasidosis Diabetikum (KAD) (50%), ARDS (50%) |
| 33 | 2025 / 12. Desember 2025 / 15 Des 2025 Div Hema (Nefroblastoma).docx | Nefroblastoma | Nefroblastoma (Wilms) (100%) |
| 34 | 2025 / 12. Desember 2025 / 19 Des 2025 Div Nefro (RPGN).docx | RPGN | RPGN (100%) |
| 35 | 2025 / 12. Desember 2025 / 22 Desember 2025-Notulensi Konfrens Divisi Gastrohepatologi.docx | Gastroenterologi | Gastroenterologi - Pembahasan Kasus (100%) |
| 36 | 2025 / 12. Desember 2025 / 24 Des 2025 - Div Neonatologi (MAS).docx | MAS | Meconium Aspiration Syndrome (MAS) (100%) |
| 37 | 2025 / 12. Desember 2025 / 29 Des 2025 - Div Neuro (Encephalomalacia).docx | Encephalomalacia | Neurologi - Pembahasan Kasus (100%) |
| 38 | 2025 / 12. Desember 2025 / 3 Des 2025 Div Respi (TB Paru on treatment).docx | TB Paru on treatment | Tuberkulosis (100%) |
| 39 | 2025 / 12. Desember 2025 / 5 Des 2025 Div Neuro (Epilepsi).docx | Epilepsi | Epilepsi/Kejang (100%) |
| 40 | 2025 / 12. Desember 2025 / 8 Des 2025 Div Nefro (Sindrom Nefritik Akut).docx | Sindrom Nefritik Akut | Sindrom Nefritik Akut (SNA) (100%) |
| 41 | 2025 / 5. Mei 2025 / 14 Mei 2025 Div HO (Thalassemia Beta Mayor).docx | Thalassemia Beta Mayor | Thalassemia (100%) |
| 42 | 2025 / 5. Mei 2025 / 16 Mei 2025 Div Alergi Imun (Hyper IgE Syndrome).docx | Hyper IgE Syndrome | Hyper IgE Syndrome (100%) |
| 43 | 2025 / 5. Mei 2025 / 19 Mei 2025 Div Introp (HIV).docx | HIV | HIV/AIDS (100%) |
| 44 | 2025 / 5. Mei 2025 / 2 Mei 2025 Div Neonatologi (Kejang Neonatorum).docx | Kejang Neonatorum | Epilepsi/Kejang (100%) |
| 45 | 2025 / 5. Mei 2025 / 21 Mei 2025 Div Kardio (CHD).docx | CHD | CHD/PJB (100%) |
| 46 | 2025 / 5. Mei 2025 / 23 Mei 2025 Div Endokrin (CAH).docx | CAH | Hiperplasia Adrenal Kongenital (CAH) (100%) |
| 47 | 2025 / 5. Mei 2025 / 26 Mei 2025 Div Respirologi (Chylothorax.docx | Respirologi | Chylothorax (100%) |
| 48 | 2025 / 5. Mei 2025 / 5 Mei 2025 Div ETIA (Fibrosis Paru).docx | Fibrosis Paru | Fibrosis Paru (100%) |
| 49 | 2025 / 5. Mei 2025 / 5. NOTULENSI KONFRENS MEI 2025.pdf | Multi-kasus (konfrens bulanan) | Neurologi - Pembahasan Kasus (17%), Hemato-Onkologi - Pembahasan Kasus (17%), Alergi-Imunologi - Pembahasan Kasus (17%), Neonatologi - Pembahasan Kasus (17%), Infeksi-Tropis - Pembahasan Kasus (16%), ETIA-Emergensi - Pembahasan Kasus (16%) |
| 50 | 2025 / 5. Mei 2025 / 7 Mei 2025 Div Neuro (Abses serebri).docx | Abses serebri | Abses Serebri (100%) |
| 51 | 2025 / 6. Juni 2025 / ETIA - Drowning.docx | ETIA-Emergensi | Drowning (100%) |
| 52 | 2025 / 6. Juni 2025 / ETIA - Meningoencephalitis.docx | ETIA-Emergensi | Ensefalitis (100%) |
| 53 | 2025 / 6. Juni 2025 / GEH - Choledochal cyst type IVA.docx | Gastroenterologi | Choledochal Cyst (100%) |
| 54 | 2025 / 6. Juni 2025 / Hema - Yolk Sac Tumor.docx | Hemato-Onkologi | Yolk Sac Tumor (100%) |
| 55 | 2025 / 6. Juni 2025 / Introp - Leptospirosis.docx | Infeksi-Tropis | Leptospirosis (100%) |
| 56 | 2025 / 6. Juni 2025 / Neo - Hiperbilirubinemia.docx | Neonatologi | Hiperbilirubinemia (100%) |
| 57 | 2025 / 6. Juni 2025 / Neuro - Epilepsy.docx | Neurologi | Neurologi - Pembahasan Kasus (100%) |
| 58 | 2025 / 6. Juni 2025 / Respi - TB Klinis dan TPT.docx | Respirologi | Tuberkulosis (50%), TB Klinis & TPT (50%) |
| 59 | 2025 / 7. Juli 2025 / 10 Jul 2025 Div HO (Anemia aplastik dd Leukemia + Post status epileptikus + App perforasi) & Div ETIA (ARDS + CAP + PJR).docx | Anemia aplastik dd Leukemia + Post status epileptikus + App perforasi | Pneumonia/CAP (13%), Epilepsi/Kejang (13%), Leukemia (13%), Anemia Aplastik (13%), Anemia (12%), Penyakit Jantung Rematik (PJR) (12%), ARDS (12%), Status Epileptikus (12%) |
| 60 | 2025 / 7. Juli 2025 / 11 Jul 2025 Div Respi (TB + Down Syndrome + ADB dd APK + Trombositopenia).docx | TB + Down Syndrome + ADB dd APK + Trombositopenia | Tuberkulosis (100%) |
| 61 | 2025 / 7. Juli 2025 / 14 Jul 2025 Div Introp (Dengue with warning sign + Faringitis akut + Peningkatan Enzim Transaminase) & (Kawasaki Disease + Sepsis + Selulitis).docx | Dengue with warning sign + Faringitis akut + Peningkatan Enzim Transaminase | Penyakit Kawasaki (20%), Demam Dengue (20%), Selulitis (20%), Sepsis (20%), Dengue (20%) |
| 62 | 2025 / 7. Juli 2025 / 16 Jul 2025 Div Alergi Imun (HSP + Trombositosis reaktif).docx | HSP + Trombositosis reaktif | Henoch-Schonlein Purpura (HSP) (100%) |
| 63 | 2025 / 7. Juli 2025 / 18 Jul 2025 Div ETIA (ARDS + AKI + Paraquat Intoxication + CAP + Intake tidak terjamin).docx | ARDS + AKI + Paraquat Intoxication + CAP + Intake tidak terjamin | Acute Kidney Injury (AKI) (25%), Pneumonia/CAP (25%), ARDS (25%), Paraquat Intoxication (25%) |
| 64 | 2025 / 7. Juli 2025 / 2 Jul 2025 Div TKPS (Bayi Lahir Dari Ibu dengan HBsAg positif dan pengobatan HIV).docx | Bayi Lahir Dari Ibu dengan HBsAg positif dan pengobatan HIV | HIV/AIDS (50%), Hepatitis B (HBsAg) (50%) |
| 65 | 2025 / 7. Juli 2025 / 21 Jul 2025 Div HO (Leukemia + Anemia + Trombositopenia + Hiperleukositosis + TFA).docx | Leukemia + Anemia + Trombositopenia + Hiperleukositosis + TFA | Leukemia (34%), Hiperleukositosis (33%), Anemia (33%) |
| 66 | 2025 / 7. Juli 2025 / 22 Jul 2025 Div Endokrin (DM).docx | DM | Diabetes Mellitus (100%) |
| 67 | 2025 / 7. Juli 2025 / 28 Jul 2025 Div Alergi Imun (Septic arthritis dd JIA + Suspek alergi makanan + Leukositosis).docx | Septic arthritis dd JIA + Suspek alergi makanan + Leukositosis | Septic Arthritis (100%) |
| 68 | 2025 / 7. Juli 2025 / 30 Jul 2025 Div Neo (RDN + CCHD).docx | RDN + CCHD | Respiratory Distress (RDN) (50%), CCHD (50%) |
| 69 | 2025 / 7. Juli 2025 / 4 Jul 2025 Div Kardio (PAPVD).docx | PAPVD | PAPVD (100%) |
| 70 | 2025 / 7. Juli 2025 / 7 Jul 2025 Div Nefro (SNRS + CAP + Hiponatremia).docx | SNRS + CAP + Hiponatremia | Pneumonia/CAP (34%), Sindrom Nefrotik (33%), Hiponatremia (33%) |
| 71 | 2025 / 7. Juli 2025 / 7. NOTULENSI KONFRENS JULI 2025.pdf | Multi-kasus (konfrens bulanan) | Nefrologi - Pembahasan Kasus (20%), Endokrinologi - Pembahasan Kasus (20%), Hemato-Onkologi - Pembahasan Kasus (20%), Alergi-Imunologi - Pembahasan Kasus (20%), ETIA-Emergensi - Pembahasan Kasus (20%) |
| 72 | 2025 / 8. Agustus 2025 / 1 Ags 2025 Div Neuro (GBS).docx | GBS | Guillain-Barre Syndrome (GBS) (100%) |
| 73 | 2025 / 8. Agustus 2025 / 11 Ags 2025 Div Alergi Imun (Reaksi Anafilaktik).docx | Reaksi Anafilaktik | Reaksi Anafilaktik (100%) |
| 74 | 2025 / 8. Agustus 2025 / 13 Ags 2025 Div Kardio (Right Heart Failure).docx | Right Heart Failure | Right Heart Failure (100%) |
| 75 | 2025 / 8. Agustus 2025 / 15 Ags 2025 Div NPM (Scurvy).docx | Scurvy | Scurvy (Defisiensi Vitamin C) (100%) |
| 76 | 2025 / 8. Agustus 2025 / 20 Ags 2025 Div NPM (Scurvy).docx | Scurvy | Scurvy (Defisiensi Vitamin C) (100%) |
| 77 | 2025 / 8. Agustus 2025 / 22 Ags 2025 Div Neonatologi (RDN, CHD, Neonatal Seizure - Pierre Robin Sequel, Hyponatremia).docx | RDN, CHD, Neonatal Seizure - Pierre Robin Sequel, Hyponatremia | Respiratory Distress (RDN) (34%), CHD/PJB (33%), Neonatal Seizure (33%) |
| 78 | 2025 / 8. Agustus 2025 / 25 Ags 2025 Div Endokrin (CAH).docx | CAH | Hiperplasia Adrenal Kongenital (CAH) (100%) |
| 79 | 2025 / 8. Agustus 2025 / 27 Ags 2025 Div Introp (Sifilis Kongenital).docx | Sifilis Kongenital | Sifilis Kongenital (100%) |
| 80 | 2025 / 8. Agustus 2025 / 29 Ags 2025 Div TKPS (KIPI).docx | KIPI | KIPI (100%) |
| 81 | 2025 / 8. Agustus 2025 / 4 Ags 2025 Div Nefro (SNA + AKI).docx | SNA + AKI | Acute Kidney Injury (AKI) (50%), Sindrom Nefritik Akut (SNA) (50%) |
| 82 | 2025 / 8. Agustus 2025 / 6 Ags 2025 Div Introp (Dengue Fever).docx | Dengue Fever | Demam Dengue (50%), Dengue (50%) |
| 83 | 2025 / 8. Agustus 2025 / 8 Ags 2025 Div Respi (Asma bronkial).docx | Asma bronkial | Asma Bronkial (100%) |
| 84 | 2025 / 8. Agustus 2025 / 8. Notulensi Konfrens Agustus 2025.docx | Multi-kasus (konfrens bulanan) | Kardiologi - Pembahasan Kasus (17%), Endokrinologi - Pembahasan Kasus (17%), Alergi-Imunologi - Pembahasan Kasus (17%), Neonatologi - Pembahasan Kasus (17%), Infeksi-Tropis - Pembahasan Kasus (16%), Nutrisi-Metabolik - Pembahasan Kasus (16%) |
| 85 | 2025 / 9. Notulensi Konfrens September 2025.docx | Multi-kasus (konfrens bulanan) | Nefrologi - Pembahasan Kasus (17%), Respirologi - Pembahasan Kasus (17%), Endokrinologi - Pembahasan Kasus (17%), Hemato-Onkologi - Pembahasan Kasus (17%), Alergi-Imunologi - Pembahasan Kasus (16%), Neonatologi - Pembahasan Kasus (16%) |
| 86 | 2025 / 9. September 2025 / 1 Sept 2025 Div Neuro (Status Epileptikus).docx | Status Epileptikus | Epilepsi/Kejang (50%), Status Epileptikus (50%) |
| 87 | 2025 / 9. September 2025 / 10 Sept 2025 Div Neonatologi (RDN ec HMD + PJB Asianotik ec ASD dan PDA) dan Div Respi (TB Paru).docx | RDN ec HMD + PJB Asianotik ec ASD dan PDA | Tuberkulosis (17%), HMD (Hyaline Membrane Disease) (17%), Respiratory Distress (RDN) (17%), CHD/PJB (17%), ASD (16%), PDA (16%) |
| 88 | 2025 / 9. September 2025 / 12 Sept 2025 Div Endokrin (DM Type 2).docx | DM Type 2 | Diabetes Mellitus (100%) |
| 89 | 2025 / 9. September 2025 / 15 Sept 2025 Div Alergi Imun (Urtikaria akut ec suspek alergi makanan).docx | Urtikaria akut ec suspek alergi makanan | Urtikaria (100%) |
| 90 | 2025 / 9. September 2025 / 17 Sept 2025 Div Neonatologi (Hypertrophic Pyloric Stenosis).docx | Hypertrophic Pyloric Stenosis | Hypertrophic Pyloric Stenosis (100%) |
| 91 | 2025 / 9. September 2025 / 19 Sept 2025 Div Alergi Imun (HSP).docx | HSP | Henoch-Schonlein Purpura (HSP) (100%) |
| 92 | 2025 / 9. September 2025 / 22 Sept 2025 Div Neuro (Paraplegia ec muscle spasm).docx | Paraplegia ec muscle spasm | Paraplegia (100%) |
| 93 | 2025 / 9. September 2025 / 24 Sept 2025 Div Kardio (Kawasaki Disease).docx | Kawasaki Disease | Penyakit Kawasaki (100%) |
| 94 | 2025 / 9. September 2025 / 26 Sept 2025 Div Hematoonkologi (ITP).docx | ITP | ITP (100%) |
| 95 | 2025 / 9. September 2025 / 29 Sept 2025 Div Respi (Corpus alienum bronkus) & Div Kardio (Decompensatio cordis ec PJR).docx | Corpus alienum bronkus | Penyakit Jantung Rematik (PJR) (50%), Corpus Alienum (50%) |
| 96 | 2025 / 9. September 2025 / 3 Sept 2025 Div Nefro (Abdominal pain ec suspek pyelonefritis).docx | Abdominal pain ec suspek pyelonefritis | Pyelonefritis (100%) |
| 97 | 2025 / 9. September 2025 / 8 Sept 2025 Div Hematoonkologi (Hiperleukositosis + Leukemia).docx | Hiperleukositosis + Leukemia | Leukemia (50%), Hiperleukositosis (50%) |
| 98 | 2025 / 9. September 2025 / 9. Notulensi Konfrens September 2025.docx | Multi-kasus (konfrens bulanan) | Nefrologi - Pembahasan Kasus (17%), Respirologi - Pembahasan Kasus (17%), Endokrinologi - Pembahasan Kasus (17%), Hemato-Onkologi - Pembahasan Kasus (17%), Alergi-Imunologi - Pembahasan Kasus (16%), Neonatologi - Pembahasan Kasus (16%) |
| 99 | 2026 / April / 1 April 2026 Div Neurologi (Epilepsi ec Bangkitan Kejang)).pdf | Epilepsi ec Bangkitan Kejang | Epilepsi/Kejang (100%) |
| 100 | 2026 / April / 10 April 2026 Divisi Kardiologi ( Infective Endokarditis, VSD).pdf | Infective Endokarditis, VSD | VSD (50%), Infective Endokarditis (50%) |
| 101 | 2026 / April / 15 April 2026 Divisi Respirologi dan Divisi Alergi dan imunologi.pdf | Respirologi | Respirologi - Pembahasan Kasus (100%) |
| 102 | 2026 / April / 17 April 2026 Notulensi Konferens TKPS.docx | TKPS | TKPS - Pembahasan Kasus (100%) |
| 103 | 2026 / April / 20 April 2026 Divisi NPM (Scurvy, Nutritional marasmus, intake tidak terjamin).pdf | Scurvy, Nutritional marasmus, intake tidak terjamin | Scurvy (Defisiensi Vitamin C) (50%), Gizi Buruk Marasmus (50%) |
| 104 | 2026 / April / 22 April 26_DIVISI KARDIOLOGI _ PENYAKIT JANTUNG REMATIK.pdf | Kardiologi | Penyakit Jantung Rematik (PJR) (100%) |
| 105 | 2026 / April / 24 April 2026 Div Respirologi (Abses Paru)-2.docx | Abses Paru | Abses Paru (100%) |
| 106 | 2026 / April / 27 April 2026 Divisi Alergi & Imunologi (HSP) .docx | HSP | Henoch-Schonlein Purpura (HSP) (100%) |
| 107 | 2026 / April / 6 April 2026 Divisi Neonatologi RDN.pdf | Neonatologi | Respiratory Distress (RDN) (100%) |
| 108 | 2026 / April / 8 April 2026 Divisi Hematoonkologi ( Hiperleukositosis + Leukemia ).pdf | Hiperleukositosis + Leukemia | Leukemia (50%), Hiperleukositosis (50%) |
| 109 | 2026 / April / Notulensi Konferens 13 April 2026 Divisi Kardiologi (PAPVD + Pneumonia + HIV)).docx | PAPVD + Pneumonia + HIV | Pneumonia/CAP (34%), HIV/AIDS (33%), PAPVD (33%) |
| 110 | 2026 / Februari / 16 Feb 2026 Div Endokrin (DM Tipe 1).docx | DM Tipe 1 | Diabetes Mellitus (100%) |
| 111 | 2026 / Februari / 2 Feb 2026 Div Nefrologi (ISK).pdf | ISK | ISK (100%) |
| 112 | 2026 / Februari / 20 Feb 2026 Div Introp (Demam Tifoid).pdf | Demam Tifoid | Demam Tifoid (100%) |
| 113 | 2026 / Februari / 23 Feb 2026 Div Alergi Imunologi (Reaksi Anafilaktik).pdf | Reaksi Anafilaktik | Reaksi Anafilaktik (100%) |
| 114 | 2026 / Februari / 25 Feb 2026 Div Hematoonkologi (AML).docx | AML | Leukemia (100%) |
| 115 | 2026 / Februari / 27 Feb 2026 Div Hematoonkologi (Hemofilia).pdf | Hemofilia | Hemofilia (100%) |
| 116 | 2026 / Februari / 4 Feb 2026 Div Endokrin (KAD).pdf | KAD | Ketoasidosis Diabetikum (KAD) (100%) |
| 117 | 2026 / Februari / 6 Feb 2026 Div Respirologi (Asma Brokhial).docx | Asma Brokhial | Asma Bronkial (100%) |
| 118 | 2026 / Februari / 9 Feb 2026  Div Neurologi (Myelitis Transversa).docx | Myelitis Transversa | Mielitis Transversa (100%) |
| 119 | 2026 / Januari / 09 Jan 2026 Div Endokrin (DM Tipe 1).pdf | DM Tipe 1 | Diabetes Mellitus (100%) |
| 120 | 2026 / Januari / 1 Jan 2026 Div Infeksi (CMV).docx | CMV | CMV (100%) |
| 121 | 2026 / Januari / 12 Jan 2026 Div Alergi Imunulogi (TEN).pdf | TEN | Toxic Epidermal Necrolysis (TEN) (100%) |
| 122 | 2026 / Januari / 14 Jan 2026 Div Neurologi (GBS).pdf | GBS | Guillain-Barre Syndrome (GBS) (100%) |
| 123 | 2026 / Januari / 19 Jan 2026.pdf | Massa Ginjal (Suspek Nefroblastoma) | Onkologi - Nefroblastoma (Tumor Wilms) (60%), Nefrologi - Massa Ginjal (40%) |
| 124 | 2026 / Januari / 23 Jan 2026 Div Neurologi (Encephalitis).pdf | Encephalitis | Ensefalitis (100%) |
| 125 | 2026 / Januari / 26 Jan 2026 Div Hematoonkologi (AML).docx | AML | Leukemia (100%) |
| 126 | 2026 / Januari / 30 Jan 2026 Divi Respirologi (CAP).pdf | CAP | Pneumonia/CAP (100%) |
| 127 | 2026 / Januari / 5 Jan 2026 Div Respirologi (TB).pdf | TB | Tuberkulosis (100%) |
| 128 | 2026 / Januari / 7 Jan 2026 Div Kardiologi (Kawasaki Disease).docx | Kawasaki Disease | Penyakit Kawasaki (100%) |
| 129 | 2026 / Januari / Notulen Konferens (28 Januari 2026).docx | 28 Januari 2026 | Pediatri Umum (100%) |
| 130 | 2026 / Juli / 03 Juli Notulensi Konfrens Gitelman_Syndrome (1).pdf | Gitelman Syndrome | Nefrologi - Gitelman Syndrome (60%), Endokrinologi - Hipokalemia (40%) |
| 131 | 2026 / Juli / 25 Juli 2026 - Notulensi Konfrens Scurvy (2).pdf | Multi-kasus (konfrens bulanan) | Scurvy (Defisiensi Vitamin C) (100%) |
| 132 | 2026 / Juli / NOTULEN KONFERENS 06JULI2026.pdf | Multi-kasus (konfrens bulanan) | Nutrisi-Metabolik - Pembahasan Kasus (100%) |
| 133 | 2026 / Juli / NOTULEN KONFERENS 29 JUNI 2026.pdf | Multi-kasus (konfrens bulanan) | Infeksi-Tropis - Pembahasan Kasus (100%) |
| 134 | 2026 / Juli / NOTULENSI KONFERENS 20 JULI 2026 HEMATOONKOLOGI.pdf | Hemato-Onkologi | Hemato-Onkologi - Pembahasan Kasus (100%) |
| 135 | 2026 / Juli / NOTULENSI KONFRENS 10 JULI 2026.pdf | Multi-kasus (konfrens bulanan) | Nutrisi-Metabolik - Pembahasan Kasus (50%), TKPS - Pembahasan Kasus (50%) |
| 136 | 2026 / Juli / Notulensi Konferens 22-07-2026.pdf | Multi-kasus (konfrens bulanan) | Nefrologi - Pembahasan Kasus (34%), Endokrinologi - Pembahasan Kasus (33%), Nutrisi-Metabolik - Pembahasan Kasus (33%) |
| 137 | 2026 / Juli / Notulensi Konferens 27 Juli 2026.pdf | Multi-kasus (konfrens bulanan) | Alergi-Imunologi - Pembahasan Kasus (100%) |
| 138 | 2026 / Juli / Notulensi Konferensi Senin, 13:07:2026.pdf | Efusi Pleura + Massa Paru | Respirologi - Efusi Pleura (60%), Onkologi - Massa Paru (40%) |
| 139 | 2026 / Juli / Notulensi Konfrens 08 Juli 2026.pdf | Multi-kasus (konfrens bulanan) | Neurologi - Pembahasan Kasus (100%) |
| 140 | 2026 / Juli / Notulensi Konfrens 15 Juli 2026.pdf | Multi-kasus (konfrens bulanan) | Kardiologi - Pembahasan Kasus (100%) |
| 141 | 2026 / Juli / Notulensi Konfrens 17 JULI 2026.pdf | Multi-kasus (konfrens bulanan) | Neurologi - Pembahasan Kasus (100%) |
| 142 | 2026 / Juli / Notulensi Koonfrens 1 juli 2026.pdf | Multi-kasus (konfrens bulanan) | Neonatologi - Pembahasan Kasus (100%) |
| 143 | 2026 / Juni / 12 juni 2026 hematologi dan onkologi / Konfrens 12 juni 2026.pdf | Hemato-Onkologi | Hemato-Onkologi - Pembahasan Kasus (100%) |
| 144 | 2026 / Juni / 15 Juni 2026 / Notulensi konfrens 15 juni 2026.pdf | Multi-kasus (konfrens bulanan) | Nefrologi - Pembahasan Kasus (100%) |
| 145 | 2026 / Juni / 29 Juni 2026 / Notulensi Konfrens 29 juni 2026.pdf | Multi-kasus (konfrens bulanan) | Neurologi - Pembahasan Kasus (100%) |
| 146 | 2026 / Juni / 3 Juni / Hiperleukositosis - DIVISI HEMATOONKOLOGI - 3 Juni 2026.pdf | Hemato-Onkologi | Hiperleukositosis (100%) |
| 147 | 2026 / Juni / Notulensi Konferens 24-06-2026.pdf | Multi-kasus (konfrens bulanan) | Nefrologi - Pembahasan Kasus (50%), Alergi-Imunologi - Pembahasan Kasus (50%) |
| 148 | 2026 / Maret / 11 Mar 2026 Div Introp (Morbili).pdf | Morbili | Morbili (Campak) (100%) |
| 149 | 2026 / Maret / 16 Mar 2026 Div Respirologi (TB).docx | TB | Tuberkulosis (100%) |
| 150 | 2026 / Maret / 2 Mar 2026 Div GEH (Perdarahan Saluran Cerna).docx | Perdarahan Saluran Cerna | Perdarahan Saluran Cerna (100%) |
| 151 | 2026 / Maret / 2 Mar 2026 Div Nefrologi (Sindrom Nefrotik).docx | Sindrom Nefrotik | Sindrom Nefrotik (100%) |
| 152 | 2026 / Maret / 6 Mar 2026 Div Introp (Malaria).pdf | Malaria | Infeksi-Tropis - Pembahasan Kasus (100%) |
| 153 | 2026 / Maret / Notulensi  27 Maret 2026 Div Nefrologi (Sindrom Nefrotik Resisten Steroid).docx | Sindrom Nefrotik Resisten Steroid | Sindrom Nefrotik (50%), Sindrom Nefrotik Resisten Steroid (50%) |
| 154 | 2026 / Maret / Notulensi 12 Maret 2026 Div NICU (TGA).docx | TGA | TGA (100%) |
| 155 | 2026 / Maret / Notulensi 25 Maret 2026 Div Endokrinologi (KAD).pdf | KAD | Ketoasidosis Diabetikum (KAD) (100%) |
| 156 | 2026 / Maret / Notulensi 25 Maret 2026 Divisi Endokrinologi (KAD).pdf | KAD | Ketoasidosis Diabetikum (KAD) (100%) |
| 157 | 2026 / Mei / Konfrens 25 mei 2026.pdf | Multi-kasus (konfrens bulanan) | Endokrinologi - Pembahasan Kasus (100%) |
| 158 | 2026 / Mei / Notulensi Konferens, 11 Mei 2026.pdf | Multi-kasus (konfrens bulanan) | Hemato-Onkologi - Pembahasan Kasus (100%) |
| 159 | 2026 / Mei / Notulensi Konferens, 20 Mei 2026.docx | Neonatologi | Neonatologi - Pembahasan Kasus (100%) |
| 160 | 2026 / Mei / Notulensi Konferens, 4 Mei 2026.docx | Multi-kasus (konfrens bulanan) | Neonatologi - Pembahasan Kasus (100%) |
| 161 | 2026 / Mei / Notulensi Konfrens 13 Mei 2026.docx | Infeksi Tropis | Infeksi-Tropis - Pembahasan Kasus (100%) |
| 162 | 2026 / Mei / Notulensi Konfrens 18 mei 2026.pdf | Multi-kasus (konfrens bulanan) | Neurologi - Pembahasan Kasus (100%) |
| 163 | 2026 / Mei / Notulensi konferens, 22 Mei 2026.docx | ETIA-Emergensi | ETIA-Emergensi - Pembahasan Kasus (100%) |
| 164 | 2026 / Mei / Notulensi konfrens 06 Mei 2026.pdf | Multi-kasus (konfrens bulanan) | Nutrisi-Metabolik - Pembahasan Kasus (100%) |