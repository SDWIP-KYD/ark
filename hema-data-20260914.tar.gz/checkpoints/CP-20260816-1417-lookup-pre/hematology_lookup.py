#!/usr/bin/env python3
"""hematology_lookup.py — real-time lab lookup by NORM via SIMRS resume/hasillab chain.
Used by hemato_notes_server.py /api/lookup/<NORM> endpoint.
Returns: {success, name, norm, visits:[{tgl, params}], total_records}
"""
import requests
from collections import OrderedDict

BASE = "http://localhost:8080/webservice"
LOGIN = "nadirahrasyid"
PASS = "sirs123"
TIMEOUT = 30

def make_session():
    s = requests.Session()
    try:
        r = s.post(f"{BASE}/authentication/login", json={'LOGIN':LOGIN,'PASSWORD':PASS,'CAPTCHA':'x'}, timeout=15)
        if r.json().get('success'):
            return s
    except Exception as e:
        return None
    return None

def get_nopens(s, norm):
    try:
        r = s.get(f"{BASE}/berkas-klaim/pendaftaran", params={'NORM':norm}, timeout=15).json()
        if not r.get('success'):
            # relogin once
            s.post(f"{BASE}/authentication/login", json={'LOGIN':LOGIN,'PASSWORD':PASS,'CAPTCHA':'x'}, timeout=15)
            r = s.get(f"{BASE}/berkas-klaim/pendaftaran", params={'NORM':norm}, timeout=15).json()
        return [x['NOMOR'] for x in (r.get('data') or [])]
    except Exception:
        return []

def get_kl_list(s, nopen):
    try:
        r = s.get(f"{BASE}/medicalrecord/resume/hasillab", params={'NOPEN':nopen}, timeout=15).json()
        out = []
        for lab in (r.get('data') or []):
            kl = lab.get('KUNJUNGAN_LAB')
            if kl:
                out.append((kl, lab.get('TGL','')[:19]))
        return out
    except Exception:
        return []

def get_detil(s, kl):
    try:
        r = s.get(f"{BASE}/medicalrecord/resume/hasillab/detil", params={'KUNJUNGAN_LAB':kl}, timeout=15).json()
        return r.get('data') or []
    except Exception:
        return []

def extract_visit(kl, tgl, params):
    vd = {'tgl':tgl, 'vid':kl, 'params':[]}
    for p in params:
        name = str(p.get('PARAMETER','?') or '')
        if not name or name == '-':
            continue
        vd['params'].append({
            'name': name,
            'hasil': str(p.get('HASIL','') or ''),
            'normal': str(p.get('NILAI_RUJUKAN','') or p.get('NORMAL','') or ''),
            'satuan': str(p.get('SATUAN',{}).get('DESKRIPSI','') if isinstance(p.get('SATUAN'),dict) else p.get('SATUAN','') or '')
        })
    return vd

def get_patient_name(s, norm):
    try:
        r = s.get(f"{BASE}/pasien/{norm}", timeout=15)
        if r.status_code == 200:
            d = r.json()
            for k in ('NAMA', 'name', 'nama'):
                if d.get(k):
                    return d.get(k)
            if isinstance(d.get('data'), dict):
                return d['data'].get('NAMA') or d['data'].get('nama')
    except Exception:
        pass
    return None

def lookup(norm):
    """Full chain lookup. Returns dict with success flag."""
    try:
        n = str(int(norm))
    except Exception:
        return {'success': False, 'error': 'NORM harus angka'}

    s = make_session()
    if not s:
        return {'success': False, 'error': 'SIMRS tidak reachable / login gagal'}

    nopens = get_nopens(s, n)
    if not nopens:
        return {'success': False, 'error': 'Pasien tidak ditemukan (NORM salah atau belum pernah daftar)'}

    name = get_patient_name(s, n)
    visits = OrderedDict()
    for nopen in nopens:
        for kl, tgl in get_kl_list(s, nopen):
            if kl in visits:
                continue
            params = get_detil(s, kl)
            if params:
                visits[kl] = extract_visit(kl, tgl, params)

    lst = sorted(visits.values(), key=lambda x: x['tgl'], reverse=True)
    return {
        'success': True,
        'name': name,
        'norm': n,
        'visits': lst,
        'total_records': len(visits)
    }

if __name__ == '__main__':
    import sys, json
    norm = sys.argv[1] if len(sys.argv) > 1 else '1456769'
    print(json.dumps(lookup(norm), ensure_ascii=False, indent=1)[:500])
