# CHECKPOINT ID: `CP-20260816-0946`
**Timestamp:** Minggu, 16 Agustus 2026, 09:46 WITA  
**Status Sistem:** STABLE & VERIFIED (Production Ready)

---

### 📦 **Daftar File yang Di-backup:**
1. `simrs_lab_56p.pkl` — Data Lab Rutin Hybrid (56 pasien, 200 max records + true total count).
2. `simrs_special_56p.pkl` — Data Penunjang Khusus (56 pasien: PA, Rad, BMP, LCS, Immuno, IHC).
3. `patients_16agustus.py` — Master list 56 pasien aktif Minggu 16 Agustus 2026.
4. `gen_16agustus_html.py` — Generator HTML report dengan clustering waktu (≤2 jam digabung, >2 jam dipisah) & limit 5 kunjungan awal.
5. `update_lab.py` — Engine update mandiri lab rutin (anti tumpang tindih).
6. `update_special.py` — Engine update mandiri special modules (anti tumpang tindih).
7. `fetch_special_15agustus.py` — Core SIMRS connector dengan targeted search PA/Rad/BMP/LCS/Immuno/IHC (fast ~4s/pasien).
8. `hemato_notes_server.py` — Backend server port 8788 (dukung dynamic `/api/patient/<norm>` untuk load +xx kunjungan lagi & persistent notes).
9. `Rekap_Lab_Hemato_56P_2026-08-16.html` — Output HTML statis yang sedang live di `hema.ark-kay.my.id`.

---

### 🔄 **Cara Restore ke Checkpoint Ini:**
Jalankan perintah berikut di terminal:
```bash
cp /home/lenovo/Sync/Seno/Hermes-Outputs/checkpoints/CP-20260816-0946/simrs_lab_56p.pkl /tmp/simrs_15agustus_full.pkl
cp /home/lenovo/Sync/Seno/Hermes-Outputs/checkpoints/CP-20260816-0946/simrs_special_56p.pkl /tmp/simrs_special_15agustus.pkl
cp /home/lenovo/Sync/Seno/Hermes-Outputs/checkpoints/CP-20260816-0946/patients_16agustus.py /home/lenovo/
cp /home/lenovo/Sync/Seno/Hermes-Outputs/checkpoints/CP-20260816-0946/gen_16agustus_html.py /home/lenovo/
cp /home/lenovo/Sync/Seno/Hermes-Outputs/checkpoints/CP-20260816-0946/update_lab.py /home/lenovo/
cp /home/lenovo/Sync/Seno/Hermes-Outputs/checkpoints/CP-20260816-0946/update_special.py /home/lenovo/
cp /home/lenovo/Sync/Seno/Hermes-Outputs/checkpoints/CP-20260816-0946/fetch_special_15agustus.py /home/lenovo/
cp /home/lenovo/Sync/Seno/Hermes-Outputs/checkpoints/CP-20260816-0946/hemato_notes_server.py /home/lenovo/.hermes/scripts/
systemctl --user restart hema-report.service
```
