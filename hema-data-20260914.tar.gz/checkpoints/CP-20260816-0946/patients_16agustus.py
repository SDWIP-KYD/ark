#!/usr/bin/env python3
"""Patient master list — Minggu, 16 Agustus 2026 (Updated list 55 pasien)."""
PATIENTS = [
    # LANTAI 4 PICU
    ("Lantai 4 PICU", "Bed 10", "Bakri Abdillah", "1151276", "Acute Respiratory Distress Syndrome + Acute Lymphoblastic Leukemia L1 High Risk Relaps + Community Acquired Pneumonia + Febrile Neutropenia (severe) + Riwayat Reaksi Alergi transfusi PRC + Riwayat Reaksi Alergi transfusi Trombosit + Obesitas + Hiponatremia + Intake Tidak Terjamin", "KJS"),
    ("Lantai 4 PICU", "Bed 11", "Patta Tenri Humairah F", "1690101", "Anoxia Jaringan (teratasi) + Anemia penyakit kronik + Pemanjangan faal hemostasis + Meningoencepalitis et causa suspek tuberculosis dd bakteri + Penurunan Kesadaran et causa meningoencepalitis suspek tuberculosis dd bakteri + Post status epilepticus + Dandy-Walker syndrome + Intake tidak terjamin", "KJS"),
    ("Lantai 4 PICU", "Bed 15", "Mahira Mufidah", "1689854", "Anemia penyakit kronik dd anemia defisiensi besi + trombositopenia + Tuberculosis Paru Klinis on OAT Fase Intensif Bulan Ke-1 + Community Acquired Pneumonia (Very Severe Pneumonia) + Encephalopathy ec. brain edema dan hydrocephalus sugestif hypoxic ischemic encephalopathy + Penyakit jantung bawaan asianotik et causa Large Atrial Septal Defek + Post status epilepticus + Ulcus decubitus + Alkalosis metabolik + Hiponatremia + Hipokalemia + Stunting + Gizi buruk tipe marasmus + Intake tidak terjamin", "KJS"),

    # LANTAI 5
    ("Lantai 5", "505.1", "Andi Ayu Nindiya", "1509101", "Anoxia jaringan + Anemia Aplastik + Perdarahan Saluran Cerna (teratasi) + Severe Neutropenia + Epistaksis + Trombositopenia + Intake Tidak Terjamin (teratasi)", "LEADER"),
    ("Lantai 5", "506.3", "Andra Rayyan Nugraha", "1690470", "Hepatoblastoma + Suspek Orchitis + Anemia penyakit kronik + Prolonged Fever ec infeksi bakteri Klebsiella pneumonia ESBL + Hiponatremia + Peningkatan enzim transaminase + Gizi Buruk Tipe Marasmus + Intake Tidak Terjamin", "LEADER"),
    ("Lantai 5", "507.1", "Risma", "1656954", "Anemia Penyakit Kronik + Multiple limfadenopati + Massa paru kanan + Efusi Pleura Kanan + Efusi pericard + Leukositosis + Intake tidak terjamin", "KJS"),
    ("Lantai 5", "508.1", "M. Fahmi", "1678917", "Anoksia Jaringan + Anemia Penyakit Kronik + Inkompabilitas Minor + febrile neutropenia (Mild neutropenia) + Severe Systemic Lupus Erytematosus + Gizi Buruk Tipe Marasmus + Intake Tidak Terjamin", "KJS"),

    # LANTAI 6
    ("Lantai 6", "610.3", "Abdhy Permana Jaya", "1656392", "Anemia defisiensi besi + Anemia pasca perdarahan + Dissemintaed Intravascular Coagulation + Varises Esofagus Grade III + Trombositopenia + Hiponatremia + Pemanjangan faal hemostasis + Gizi buruk tipe marasmus + intake tidak terjamin", "KJS"),
    ("Lantai 6", "612.1", "Imanuel Naila Oagay", "1678974", "Tumor Intraabdomen ec Hepatoblastoma + Cancer Pain + Anemia penyakit kronik + Lesi cavum pelvis sugestif metastasis + Splenomegaly + Ascites + Multiple lymphadenopathy inguinal bilateral + Leukositosis + Peningkatan Enzim Transaminase + Hipoalbuminemia + Hiponatremia", "KJS"),
    ("Lantai 6", "612.2", "Muhammad Rasydan Alfatih", "1673136", "Limfoma Hodgkin dd Non Hodgkin + Efusi Pleurabilateral (perbaikan) + Proteinuria non nephrotic range + Suspek alergi obat + Suspek Alergi susu sapi + Gizi buruk tipe marasmus + Intake Tidak Terjamin", "KJS"),
    ("Lantai 6", "616.4", "Abigail Aquila Padandi", "1044068", "Anemia Penyakit Kronik + Peningkatan Enzim Transaminase + Suspek Kolangitis Akut et causa Kolestatik Intrahepatik pada pasien Stenosis Common Hepatic Duct + Infeksi CMV + Infeksi Rubella + Hiponatremia + Hipokalemia + Hipoalbuminemia", "KJS"),

    # LANTAI 7 KEMO
    ("Lantai 7 KEMO", "702.1", "Moh. Rizki Aditya", "1644861", "Acute Lymphoblastic Leukemia L1 HR", "LEADER"),
    ("Lantai 7 KEMO", "702.3", "Rayhan Al Ayyubi Faiz", "1495533", "Acute Lymphoblasic Leukemia L1 Standard Risk + Riwayat alergi leucovorin + Hiponatremia", "LEADER"),
    ("Lantai 7 KEMO", "704.1", "WIldan Nofriansyah", "1548746", "Acute Lymphoblastic Leukemia L1 Standar Risk", "LEADER"),
    ("Lantai 7 KEMO", "704.2", "Revina Jayatri", "1661157", "Osteosarcoma + Cancer pain + Thrombositosis reaktif + Hiponatremia + Hipokalemia + Gizi buruk tipe marasmus", "LEADER"),
    ("Lantai 7 KEMO", "704.3", "Rayyan Dzakki", "1460267", "Acute Lymphoblastic Leukemia L1 Standar Risk + Faringitis Akut + Selulitis Regio Manus Dextra + Dyspepsia fungsional + Riwayat Reaksi Anafilaksis Transfusi TC + Riwayat Reaksi Alergi Leunase", "LEADER"),
    ("Lantai 7 KEMO", "704.4", "Muhammad Apriankhair", "1585434", "Acute Lymphoblastic Leukemia L1 High Risk", "LEADER"),
    ("Lantai 7 KEMO", "705.1", "Maher Muntaza", "1453116", "Rhabdomyosarcoma Regio Nasal", "LEADER"),
    ("Lantai 7 KEMO", "705.2", "Naura Ayu Nindia Putri", "1026331", "Tumor Intraabdomen et causa Dysgerminoma Ovarii + Anemia penyakit kronik di Anemia Defisiensi Besi + AKI KDIGO II + Hydronephrosis Bilateral Grade III + Diare Akut + Dehidrasi Tidak Berat + Hipokalemia + Gizi Buruk Tipe Marasmus", "LEADER"),
    ("Lantai 7 KEMO", "705.4", "Mauriska Gena", "1666863", "Ewing Sarcoma", "LEADER"),
    ("Lantai 7 KEMO", "706.1", "Ahmad Adzhar Mustari", "1607137", "Lymphoma Maligna Hodgkin", "LEADER"),
    ("Lantai 7 KEMO", "706.2", "Arizky Maulana", "1445976", "Acute Lymphoblastic Leukemia L1 High Risk", "LEADER"),
    ("Lantai 7 KEMO", "706.3", "Muhammad Baim", "1509633", "Neuroblastoma + Diare Akut + Dehidrasi Tidak Berat + Anemia Penyakit Kronik + Hiponatremia + Riwayat alergi trombosit", "LEADER"),
    ("Lantai 7 KEMO", "706.4", "Muhammad Iqram Hardi", "1084180", "ALL High Risk Relaps", "LEADER"),
    ("Lantai 7 KEMO", "707.1", "Maulana Afiqurrahman", "1579413", "Acute Lymphoblastic Leukemia L1 High Risk", "LEADER"),
    ("Lantai 7 KEMO", "707.2", "Huriyah Naisha", "1672844", "Osteosarcoma + Anemia + Hiponatremia", "LEADER"),
    ("Lantai 7 KEMO", "707.3", "Ahmad Muqhawwam", "1005128", "Acute Lymphoblastic Leukemia L1 High Risk Relaps + Bell's Palsy + Riwayat Reaksi Alergi Makanan + Anemia + Thrombositopenia + Peningkatan enzim transaminase + Hipokalemia + Obesitas", "LEADER"),
    ("Lantai 7 KEMO", "707.4", "Muhammad Ahtar Syaputra", "1600708", "Retinoblastoma oculi dextra + Anemia penyakit kronik + Faringitis akut + Gizi buruk tipe marasmus", "KJS"),

    # LANTAI 7 NON KEMO
    ("Lantai 7 NON KEMO", "709.1", "Jendry Lolokassa", "1666462", "Acute Lymphoblastic Leukemia Standard Risk + Faringitis akut + Melena + Epistaksis + Anemia + Trombositopenia + Febrile Neutropenia (Profound Neutropenia) + Inkompabilitas Minor + Anoxia Jaringan + Peningkatan enzim transaminase + Gizi Kurang + Riwayat Reaksi Alergi Transfusi PRC", "LEADER"),
    ("Lantai 7 NON KEMO", "709.2", "Amelia", "1590066", "Acute Lymphoblastic Leukemia L1 High Risk + Sepsis + Community Acquired Pneumona + Faringitis Akut + Leukositosis + Trombositopenia + Febrile Neutropenia + Hiponatremia + Hipokalemia + Intake tidak terjamin + Reaksi Alergi Leunase", "LEADER"),
    ("Lantai 7 NON KEMO", "710.1", "Nur Asyafana Amelia", "1590213", "Acute Lymphoblastic Leukemia L1 Standar Risk + Cancer pain + Leukositosis + Obesitas", "LEADER"),
    ("Lantai 7 NON KEMO", "710.2", "Muhammad Syafiq Nalta", "1679115", "Acute Lymphoblastic Leukemia L1 High Risk + Community Acquired Pneumonia + Febrile neutropenia (severe netropenia)", "LEADER"),
    ("Lantai 7 NON KEMO", "710.3", "Khanza Fidelya Utami", "1690252", "Anemia penyakit kronik + Trombositopenia (teratasi) + Ketoasidosis Diabetikum Sedang (teratasi) + Diabetes Melitus Tipe I dd Diabetes Melitus Tipe II + AKI KDIGO III (teratasi) + Gangguan Penyesuaian dengan reaksi campuran anxietas dan depresi + Community Acquired Pneumonia (teratasi) + Perdarahan saluran cerna (teratasi) + Bangkitan Kejang et causa Epilepsi + Gizi kurang + Hipokalemia (teratasi) + Hiponatremia + Intake Tidak Terjamin (teratasi)", "KJS"),
    ("Lantai 7 NON KEMO", "710.4", "Andi Muhammad Al Qadri", "1696446", "Acute Lymphoblastic Leukemia L2 + Hiperleukositosis + Urtikaria + Anoksia Jaringan + Anemia + Community Acquired Pneumoniae + Down Syndrome + Mikrocephal + Gizi kurang", "LEADER"),
    ("Lantai 7 NON KEMO", "711.1", "Wirga Sajana", "1666513", "Ewing Sarcoma + Faringitis Akut + Selulitis Manus Sinistra + Diare Akut + Dehirasi tidak berat + Anemia Penyakit Kronik + Hiponatremia + Hipokalemia + Gizi Buruk Tipe Marasmus + Intake Tidak Terjamin", "LEADER"),
    ("Lantai 7 NON KEMO", "711.2", "Muhammad Al Haidar Nasril", "1701569", "Anemia penyakit kronik dd anemia defisiensi besi + Post Bangkitan kejang et causa suspek Space Occupaying Lession + Community Acquired Pneumonia + Hiperkalemia + Hiponatemia", "KJS"),
    ("Lantai 7 NON KEMO", "711.3", "Ahmad Fauzan", "1469712", "Acute Respiratory Distress Syndrome + Ewing Sarcoma + Anoksia jaringan (teratasi) + Demam tifoid + Anemia penyakit kronik + Konstipasi (teratasi) + Peningkatan enzime transaminase (teratasi) + Hiponatremia + Gizi Buruk Tipe Marasmus + Intake tidak terjamin", "LEADER"),
    ("Lantai 7 NON KEMO", "711.4", "Graivance Syalom Tangirerung", "1644534", "Anoksia jaringan + Osteosarcoma regio genu dextra + Abses Genu Dextra + Anemia penyakit kronik + Hiponatremia + Gizi Buruk Tipe Marasmus", "LEADER"),
    ("Lantai 7 NON KEMO", "712.2", "Arika Miftahul Khaera Alham", "1705492", "Leukemia + Anemia + Trombositopenia + Gizi Kurang + Stunting + Intake tidak terjamin", "LEADER"),
    ("Lantai 7 NON KEMO", "712.3", "Gusti Putu Abimanyu", "1594151", "Acute Respiratory Distress Syndrome + Reaksi Anafilaksis Transfusi Trombosit + Leukemia + Hiperleukositosis + Inkompabilitas Mayor + Trombositopenia + Hematemesis Melena", "LEADER"),
    ("Lantai 7 NON KEMO", "713.1", "Kabsyah Sudirman", "1690753", "Hiperleukositas (teratasi) + Acute Lymphoblastic Leukemia L1 + Anemia + Faringitis akut + Febrile Neutropenia (Mild Neutropenia) teratasi + Trombositopenia + Stunting", "LEADER"),
    ("Lantai 7 NON KEMO", "713.2", "Ali Juna Kazama Madong", "1576340", "Acute Myeloid Leukemia (AML M2) + Anemia + Trombositopenia (nilai kritis PLT: 7.000/ul)", "LEADER"),
    ("Lantai 7 NON KEMO", "713.3", "Muhammad Zayan Al Athar", "1701811", "Hemangioma regio parietal sinistra + Glucose-6-Phosphate Dehydrogenase (G6PD) Deficiency + Community Acquired Pneumoniae + Ulkus Regio Frontoparietal + Faringitis Akut + Leukositosis + Trombositosis reaktif + Dermatitis Atopi + Overweight", "LEADER"),
    ("Lantai 7 NON KEMO", "713.4", "Nurul Safira", "690886", "Anemia penyakit kronik + Suspek Dermatomyositis dd Systemic Lupus Erythematosus + Epidermolisis bulosa + Prolonged Fever + Leukositosis + Trombositosis Reaktif + Gizi buruk tipe marasmus + Intake tidak terjamin", "KJS"),
    ("Lantai 7 NON KEMO", "716 VIP", "Raphael Asher Lin", "1684505", "Acute Lymphoblastic Leukemia L1 High Risk + Febril neutropenia (profound neutropenia) + Faringitis akut + Anemia + Trombositopenia + ⁠Intake Tidak Terjamin", "LEADER"),

    # IRD Anak Mother And Child
    ("IRD Anak", "Bed 2", "Sajjad Athallah Sarwan", "1553769", "Nefroblastoma + Faringitis Akut + Trombositopenia", "LEADER"),
    ("IRD Anak", "Bed 3", "Azzahra Nayla Khairunnisa", "1495274", "Angiomyosarcoma + Suspek Kasabach Merritt Syndrome + Anemia + Trombositopenia + Infeksi Toxoplasmosis + Riwayat alergi transfusi TC + Gizi Buruk Tipe Marasmus", "LEADER"),

    # PJT
    ("PJT", "602", "Raini Zahra Adzanna", "1689801", "Anemia Penyakit Kronik + Prolonged Fever + Demam Tifoid + Gizi Buruk Tipe Marasmus + Intake tidak terjamin", "KJS"),
    ("PJT", "608", "Nurul Afifah Nahda", "1701981", "Anemia Penyakit Kronik dd Anemia Defisiensi Besi + Suspek Scurvy + Faringitis Akut + Intake Tidak Terjamin", "KJS"),
    ("PJT", "611.5", "Keisha Putri Fauzan", "1701619", "Anemia Defisiensi Besi dd Anemia Penyakit Kronik + Dilated Cardiomyopathy + Severe Mitral Regurgitation + Acute decompensated heart failure (ADHF) + Suspek Rheumatic Heart Disease + Gizi Kurang", "KJS"),
    ("PJT", "612.3", "Nur Sida Anastasya", "1673250", "Anemia Defisiensi Besi + Trombositopenia + Edema Cruris Sinistra et causa Lymphatic Malformation dd Abscess Cruris Sinistra + Hiponatremia", "KJS"),
    ("PJT", "612.4", "M Izzan Alfarizki", "1690656", "Anoxia jaringan + Anemia Hemolitik + Pemanjangan faal hemostasis + Kolestasis ekstrahepatik dd/ kolestasis intrahepatik + Peningkatan enzim transaminase + Hipoalbuminemia + Hiponatremia + crazy pavement dermatositosis + Gizi buruk tipe kwashiorkor + Intake tidak terjamin + Delayed Immunization", "KJS"),
    ("PJT", "613.1", "Ahmad Ali Akhtar", "1690053", "Anoksia Jaringan (teratasi) + Anemia Defisiensi Besi + Pemanjangan fungsi faal + Kolestatis intrahepatik dd ekstrahepatik + Peningkatan enzim transaminase + Infeksi Rubella + Tonsilofaringitis akut + Leukositosis", "KJS"),
    ("PJT", "613.2", "Shabrina Azzahra Khairunisa", "1701991", "Cancer pain + Suspek Nefroblastoma + Anemia Penyakit Kronik", "LEADER"),
    ("PJT", "620.3", "Nur Madinatul Ilmi", "1667061", "Anemia penyakit kronik + Penyakit Jantung Bawaan Asianotik et Causa Perimembran Ventricle Septal Defect + Tonsilofaringitis Akut + Diare Akut + Dehidrasi Tidak Berat + Hiponatremia", "KJS"),

    # PCC Lt 4
    ("PCC Lt 4", "415", "Farhan Ramadhan", "1702083", "Henoch Schonlein Purpura + Hipertensi grade II + Hematuria Mikroskopis + Leukositosis + Hipoalbuminemia + Hiponatremia + Hipokalemia + Obesitas + Intake Tidak Terjamin", "KJS"),
]
