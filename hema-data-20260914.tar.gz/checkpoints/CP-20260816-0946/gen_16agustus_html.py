#!/usr/bin/env python3
"""Hemato Lab Report Generator — List 16 Agustus 2026.
Features:
1. Grouping by Location -> Bed (Lantai 4 PICU, L5, L6, L7 Kemo/Non Kemo, IRD, PJT, PCC)
2. Accurate Patient Master integration (Lantai, Kamar, Diagnosis, Status KJS/Leader)
3. Lab Clustering: merges results on same date if within 2 hours; separates shift changes
4. Lab View Limit: displays 5 latest clustered visits by default, with +xx load button
5. Full Support for +xx more visits API
6. Special Modules: PA, Rad, BMP, LCS, Immuno, IHC
7. Note autosave to server + LocalStorage
"""
import pickle, re, os, json, sys
from collections import OrderedDict
from datetime import datetime

sys.path.insert(0, '/home/lenovo')
from patients_16agustus import PATIENTS

CRIT = {
    'hgb': (6, 18), 'hemoglobin': (6, 18), 'hb': (6, 18),
    'plt': (20, 1000), 'trombosit': (20, 1000),
    'wbc': (2, 50), 'leukosit': (2, 50),
    'natrium': (120, 160), 'kalium': (2.5, 6.5),
    'hct': (15, 60), 'hematokrit': (15, 60),
    'kreatinin': (None, 5), 'ureum': (None, 200),
    'crp': (None, 100), 'procalcitonin': (None, 50),
    'ferritin': (None, 2000), 'ferritine': (None, 2000)
}

def tv(v):
    if not v or v == '-': return None
    try: return float(v.strip().replace(',', '.').lstrip('<').lstrip('>'))
    except: return None

def pr(s):
    m = re.match(r'([\d.]+)\s*-\s*([\d.]+)', str(s).strip().replace(',', '.'))
    if m:
        try: return float(m.group(1)), float(m.group(2))
        except: pass
    return None

def classify(pv):
    hv = tv(pv.get('hasil'))
    rg = pr(pv.get('normal'))
    if hv is None or rg is None: return 'N'
    lo, hi = rg
    if hv < lo or hv > hi:
        nk = pv.get('name', '').lower().strip()
        for k, (cl, ch) in CRIT.items():
            if k in nk:
                if (cl is not None and hv < cl) or (ch is not None and hv > ch): return 'K'
        return 'A'
    return 'N'

STD_ORDER = [
    'hb', 'hgb', 'hemoglobin', 'plt', 'trombosit', 'ret', 'retikulosit', 'retikulosit%',
    'mcv', 'mch', 'mchc', 'hct', 'hematokrit', 'wbc', 'leukosit',
    'neut%', 'neutrofil%', 'neutrofil', 'lymph%', 'limfosit%', 'limfosit',
    'mono%', 'monosit%', 'monosit', 'natrium', 'na', 'kalium', 'k',
    'chlorida', 'cl', 'klorida', 'ureum', 'ur', 'kreatinin', 'cr',
    'sgot', 'ast', 'sgpt', 'alt', 'albumin'
]

def sort_params(params):
    def sk(p):
        n = p.get('name', '').lower().strip()
        for i, s in enumerate(STD_ORDER):
            if n == s or s in n or n in s: return i
        return len(STD_ORDER)
    return sorted(params, key=sk)

def cluster_labs(raw_groups):
    """Cluster lab results:
    - Same calendar day & time difference <= 2 hours -> MERGE
    - Same day & time difference > 2 hours -> KEEP SEPARATE
    - Different days -> KEEP SEPARATE
    """
    valid_groups = []
    for g in raw_groups:
        tgl_str = g.get('tgl', '')
        try:
            dt = datetime.strptime(tgl_str[:19], '%Y-%m-%d %H:%M:%S')
        except:
            try:
                dt = datetime.strptime(tgl_str[:10], '%Y-%m-%d')
            except:
                dt = datetime.min
        valid_groups.append((dt, tgl_str, g.get('params', [])))
    valid_groups.sort(key=lambda x: x[0], reverse=True)

    clustered = []
    for dt, tgl_str, params in valid_groups:
        if not clustered:
            clustered.append({'dt': dt, 'tgl': tgl_str, 'params': list(params)})
            continue
        last = clustered[-1]
        same_day = (dt.date() == last['dt'].date()) if (dt != datetime.min and last['dt'] != datetime.min) else (tgl_str[:10] == last['tgl'][:10])
        time_diff = abs((last['dt'] - dt).total_seconds()) if (dt != datetime.min and last['dt'] != datetime.min) else 999999

        if same_day and time_diff <= 7200: # 2 hours
            existing_names = {p['name'].lower().strip() for p in last['params']}
            for p in params:
                pn = p.get('name', '').lower().strip()
                if pn not in existing_names:
                    last['params'].append(p)
                    existing_names.add(pn)
        else:
            clustered.append({'dt': dt, 'tgl': tgl_str, 'params': list(params)})
            
    # Sort params in each clustered visit
    for c in clustered:
        c['params'] = sort_params(c['params'])
    return clustered

# 1. Load Lab Data & Special Data
PKL_LAB = '/tmp/simrs_15agustus_full.pkl'
PKL_SPEC = '/tmp/simrs_special_15agustus.pkl'

lab_data = pickle.load(open(PKL_LAB, 'rb')) if os.path.exists(PKL_LAB) else {}
spec_data = pickle.load(open(PKL_SPEC, 'rb')) if os.path.exists(PKL_SPEC) else {}

# 2. Build Master Patient Records from PATIENTS (16 Agustus)
patients = []
for idx, (lokasi, kamar, name, norm_raw, dx, status) in enumerate(PATIENTS):
    norm = str(int(norm_raw))
    
    # Retrieve raw labs
    l_entry = lab_data.get(norm) or {}
    raw_labs = l_entry.get('labs') or l_entry.get('visits') or []
    
    # Cluster labs
    clustered_visits = cluster_labs(raw_labs)
    
    # Retrieve special
    s_entry = spec_data.get(norm) or {}
    
    patients.append({
        'idx': idx + 1,
        'norm': norm,
        'name': name,
        'lokasi': lokasi,
        'kamar': kamar,
        'diagnosis': dx,
        'status': status,
        'visits': clustered_visits,
        'raw_total': l_entry.get('total', len(raw_labs)),
        'raw_shown': l_entry.get('shown', len(raw_labs)),
        'special': {
            'pa': s_entry.get('pa', []),
            'rad': s_entry.get('rad', []),
            'bmp': s_entry.get('bmp', []),
            'lcs': s_entry.get('lcs', []),
            'immuno': s_entry.get('immuno', []),
            'ihc': s_entry.get('ihc', [])
        }
    })

# 3. Group by Location in original order
LOC_ORDER = [
    'Lantai 4 PICU', 'Lantai 5', 'Lantai 6',
    'Lantai 7 KEMO', 'Lantai 7 NON KEMO',
    'IRD Anak', 'PJT', 'PCC Lt 4'
]

groups = OrderedDict()
for loc in LOC_ORDER:
    groups[loc] = []

for p in patients:
    lok = p['lokasi']
    if lok not in groups:
        groups[lok] = []
    groups[lok].append(p)

today = os.environ.get('REPORT_DATE', datetime.now().strftime('%Y-%m-%d'))
tm = datetime.now().strftime('%H:%M')

hparts = []
uid = [0]

for lok, pats in groups.items():
    if not pats: continue
    lbg = {
        'Lantai 4 PICU': '#f3e5f5',
        'Lantai 5': '#e8f5e9',
        'Lantai 6': '#e3f2fd',
        'Lantai 7 KEMO': '#fff3e0',
        'Lantai 7 NON KEMO': '#ffe0b2',
        'IRD Anak': '#fce4ec',
        'PJT': '#fff8e1',
        'PCC Lt 4': '#e0f2f1'
    }.get(lok, '#f5f5f5')

    hparts.append(f'<div class="loc-section"><div class="loc-title" style="background:{lbg}">{lok} <span class="count">({len(pats)})</span></div>\n')

    for p in pats:
        vs = p['visits']
        uid[0] += 1
        pid = uid[0]

        hparts.append(f'<div class="patient-card" data-name="{p["name"].lower()}" data-norm="{p["norm"]}">\n')
        hparts.append(f'<div class="patient-header" onclick="togglePatient(this)">\n')
        hparts.append(f'<div><div class="patient-name">{p["name"]} <span class="room">/ {p["kamar"]}</span></div>\n')
        hparts.append(f'<div class="patient-meta">NORM: <b>{p["norm"]}</b> | <span class="status-badge status-{p["status"].lower()}">{p["status"]}</span> | {p["diagnosis"]}</div></div>\n')
        hparts.append(f'<span class="toggle-icon">▶</span></div>\n')
        
        hparts.append(f'<div class="patient-body">\n')
        hparts.append(f'<div class="note-box"><span class="note-label">📝 Catatan:</span><textarea id="note-{pid}" class="note-input" data-norm="{p["norm"]}" oninput="noteDirty(this)" placeholder="Tulis catatan untuk pasien ini..."></textarea></div>\n')
        
        # Toggle button for Special Data
        hparts.append(f'<div class="special-toggle"><button class="special-btn" onclick="toggleSpecial(this, \'{p["norm"]}\')">📂 Tampilkan PA / Rad / BMP / LCS / Immuno / IHC</button><div class="special-result" id="special-{pid}" style="display:none;"></div></div>\n')
        
        if not vs:
            hparts.append(f'<div class="no-lab-alert">⚠️ Belum ada riwayat hasil laboratorium di SIMRS</div>\n')
            hparts.append(f'</div></div>\n')
            continue

        # Cap initial view to 5 clustered visits
        RENDER_N = 5
        shown = vs[:RENDER_N]

        tabs_html = [f'<div class="visit-tabs" id="tabs-{pid}">']
        for vi, v in enumerate(shown):
            a = "active" if vi == 0 else ""
            tgl_clean = (v.get("tgl") or "?")[:16]
            tabs_html.append(f'<div class="visit-tab {a}" onclick="showVisit(this,\'h{pid}-{vi}\')">Kunj {vi+1}<br><small>{tgl_clean}</small></div>')
        
        if len(vs) > RENDER_N:
            tabs_html.append(f'<button class="load-all-btn" id="btn-{pid}" onclick="loadAll(\'{p["norm"]}\',{pid})">+{len(vs)-RENDER_N} kunjungan lagi ▾</button>')
        tabs_html.append('</div>\n')
        hparts.append('\n'.join(tabs_html))

        # Visit panels
        for vi, v in enumerate(shown):
            a = "active" if vi == 0 else ""
            hparts.append(f'<div class="visit-panel {a}" id="h{pid}-{vi}">\n<table>\n<tr><th>Parameter</th><th>Hasil</th><th>N Normal</th><th>Satuan</th><th>Status</th></tr>\n')
            for pv in v.get('params', []):
                sp = classify(pv)
                sl = {'A': 'Bermakna', 'K': 'KRITIS', 'N': 'Normal'}[sp]
                val = str(pv.get('hasil', ''))
                if sp == 'K': val += " [K]"
                elif sp == 'A': val += " [A]"
                cls = "critical" if sp == "K" else ("abnormal" if sp == "A" else "normal")
                icon = "🔴" if sp == "K" else ("🟠" if sp == "A" else "")
                hparts.append(f'<tr><td>{pv.get("name","")}</td><td class="result-{cls}">{val}</td><td>{pv.get("normal","")}</td><td>{pv.get("satuan","")}</td><td class="status-{cls}">{icon} {sl}</td></tr>\n')
            hparts.append(f'</table>\n</div>\n')

        hparts.append(f'</div></div>\n')
    hparts.append('</div>\n')

html = f'''<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Rekap Lab Hemato {len(patients)} Pasien - {today}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#f5f6fa;color:#333;}}
.header{{background:#1a237e;color:#fff;padding:16px 20px;position:sticky;top:0;z-index:100;}}
.header h1{{font-size:18px;}}.header small{{font-size:12px;opacity:0.8;}}
.nav-bar{{background:#283593;padding:8px 12px;position:sticky;top:56px;z-index:99;display:flex;gap:4px;overflow-x:auto;white-space:nowrap;scrollbar-width:thin;align-items:center;}}
.nav-bar a{{color:#e8eaf6;text-decoration:none;font-size:11px;padding:4px 8px;border-radius:4px;flex-shrink:0;}}
.nav-bar a:hover{{background:#5c6bc0;color:#fff;}}
.nav-btn{{background:#3949ab;color:#fff;border:none;padding:4px 10px;border-radius:4px;font-size:11px;cursor:pointer;flex-shrink:0;}}
.nav-btn:hover{{background:#5c6bc0;}}
.nav-status{{color:#ffeb3b;font-size:10px;margin-left:8px;flex-shrink:0;}}
.container{{max-width:1000px;margin:0 auto;padding:12px;}}
.search-box{{margin-bottom:12px;}}
.search-box input{{width:100%;padding:8px 12px;border:1px solid #ccc;border-radius:6px;font-size:14px;outline:none;}}
.search-box input:focus{{border-color:#3f51b5;}}
.loc-section{{margin:16px 0;}}
.loc-title{{font-size:15px;font-weight:700;color:#1a237e;padding:8px 12px;border-left:4px solid #3f51b5;border-radius:6px 6px 0 0;}}
.count{{font-size:11px;color:#666;font-weight:400;}}
.patient-card{{background:#fff;margin:6px 0;box-shadow:0 1px 3px rgba(0,0,0,0.08);border-radius:6px;border:1px solid #e0e0e0;}}
.patient-header{{padding:10px 12px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;background:#fafafa;border-radius:6px;}}
.patient-header:hover{{background:#f0f0f0;}}
.patient-name{{font-weight:700;font-size:13px;color:#2c3e50;}}
.patient-name .room{{color:#e65100;font-weight:600;font-size:12px;}}
.patient-meta{{font-size:11px;color:#616161;margin-top:3px;line-height:1.4;}}
.status-badge{{padding:1px 6px;border-radius:3px;font-size:9px;font-weight:700;}}
.status-kjs{{background:#e8eaf6;color:#283593;}}
.status-leader{{background:#fbe9e7;color:#d84315;}}
.toggle-icon{{font-size:12px;color:#999;transition:transform 0.2s;}}
.open .toggle-icon{{transform:rotate(90deg);}}
.patient-body{{display:none;padding:10px;border-top:1px solid #eee;}}.open .patient-body{{display:block;}}
.note-box{{background:#fffde7;border:1px solid #f9e79f;border-radius:6px;padding:8px;margin:8px 0;}}
.note-label{{font-size:11px;font-weight:600;color:#8a6d3b;display:block;margin-bottom:4px;}}
.note-input{{width:100%;min-height:48px;border:1px solid #d4ac0d;border-radius:4px;padding:6px;font-size:12px;resize:vertical;font-family:inherit;background:#fff;}}
.note-input:focus{{outline:none;border-color:#b7950b;}}
.special-toggle{{margin:10px 0;}}
.special-btn{{background:#e65100;color:#fff;border:none;padding:8px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;width:100%;text-align:left;}}
.special-btn:hover{{background:#bf4600;}}
.special-result{{margin-top:8px;padding:10px;background:#f9f9f9;border-radius:6px;border:1px solid #e0e0e0;}}
.sp-section{{margin:8px 0;padding:8px;border-left:3px solid #e91e63;background:#fff;border-radius:4px;}}
.sp-section h4{{font-size:12px;margin-bottom:4px;color:#c2185b;}}
.sp-item{{font-size:11px;padding:3px 0;border-bottom:1px dashed #eee;line-height:1.4;}}
.badge{{background:#e91e63;color:#fff;padding:1px 5px;border-radius:8px;font-size:9px;}}
.empty{{color:#999;font-style:italic;font-size:11px;}}
.no-lab-alert{{background:#fff3e0;border:1px solid #ffe0b2;color:#e65100;padding:8px 12px;border-radius:4px;font-size:11px;margin:6px 0;}}
.visit-tabs{{display:flex;gap:4px;margin:8px 0;flex-wrap:wrap;align-items:center;}}
.visit-tab{{padding:4px 8px;border-radius:6px;font-size:10px;cursor:pointer;background:#e0e0e0;text-align:center;line-height:1.2;}}
.visit-tab.active{{background:#3f51b5;color:#fff;font-weight:600;}}
.visit-tab:hover{{background:#c5cae9;}}
.load-all-btn{{background:#eceff1;color:#455a64;border:1px solid #cfd8dc;padding:4px 8px;border-radius:6px;font-size:10px;font-weight:600;cursor:pointer;}}
.load-all-btn:hover{{background:#cfd8dc;}}
.visit-panel{{display:none;margin-top:6px;}}.visit-panel.active{{display:block;}}
table{{width:100%;border-collapse:collapse;font-size:11px;background:#fff;border-radius:4px;overflow:hidden;}}
th{{background:#37474f;color:#fff;padding:6px 8px;text-align:left;font-weight:600;}}
td{{padding:5px 8px;border-bottom:1px solid #f0f0f0;}}
tr:hover{{background:#fafafa;}}
.result-critical{{color:#c62828;font-weight:700;}}
.result-abnormal{{color:#e65100;font-weight:600;}}
.result-normal{{color:#2e7d32;}}
.status-critical{{color:#c62828;font-weight:700;}}
.status-abnormal{{color:#e65100;font-weight:600;}}
.status-normal{{color:#2e7d32;}}
</style>
</head>
<body>
<div class="header">
  <h1>🏥 Rekap Lab Hematoonkologi {len(patients)} Pasien — Agustus 2026</h1>
  <small>{today} {tm} WITA | 📝 Catatan tersimpan permanen (server) | 🟠=Bermakna 🔴=Kritis</small>
</div>
<div class="nav-bar">
  <a href="#" onclick="filterLoc('all')">📋 Semua</a>
  <a href="#" onclick="filterLoc('PICU')">🟣 PICU</a>
  <a href="#" onclick="filterLoc('Lantai 5')">🟢 Lantai 5</a>
  <a href="#" onclick="filterLoc('Lantai 6')">🔵 Lantai 6</a>
  <a href="#" onclick="filterLoc('KEMO')">🟠 KEMO</a>
  <a href="#" onclick="filterLoc('NON KEMO')">🟧 NON KEMO</a>
  <a href="#" onclick="filterLoc('IRD')">🌸 IRD</a>
  <a href="#" onclick="filterLoc('PJT')">🟡 PJT</a>
  <a href="#" onclick="filterLoc('PCC')">🔷 PCC</a>
  <button class="nav-btn" onclick="saveAll()">💾 Simpan Semua</button>
  <span class="nav-status" id="saveStatus"></span>
</div>
<div class="container">
  <div class="search-box">
    <input type="text" id="search" placeholder="🔍 Cari nama/NORM/kamar/diagnosis..." oninput="filterSearch(this.value)">
  </div>
  {''.join(hparts)}
</div>
<script>
var NOTES={{}};var SAVE_TIMER=null;
function normOf(t){{var c=t.closest('.patient-card');return c?c.dataset.norm:'';}}
function loadNotes(){{fetch('/api/notes').then(r=>r.json()).then(function(data){{NOTES=data||{{}};document.querySelectorAll('.note-input').forEach(function(t){{var n=t.dataset.norm;if(n&&NOTES[n])t.value=NOTES[n];}});setStatus('✅ Catatan dimuat ('+Object.keys(NOTES).length+')');}}).catch(function(){{setStatus('⚠️ Server catatan tidak bisa diakses — catatan tdk tersimpan permanen');}});}}
function noteDirty(t){{clearTimeout(SAVE_TIMER);SAVE_TIMER=setTimeout(function(){{saveOne(t);}},800);}}
function saveOne(t){{var n=t.dataset.norm;if(!n)return;NOTES[n]=t.value;setStatus('Menyimpan...');fetch('/api/notes',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(NOTES)}}).then(r=>r.json()).then(function(){{setStatus('✅ Tersimpan '+Object.keys(NOTES).length);}}).catch(function(){{setStatus('⚠️ Gagal simpan');}});}}
function saveAll(){{document.querySelectorAll('.note-input').forEach(function(t){{NOTES[t.dataset.norm]=t.value;}});setStatus('Menyimpan semua...');fetch('/api/notes',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(NOTES)}}).then(r=>r.json()).then(function(){{setStatus('✅ Semua tersimpan ('+Object.keys(NOTES).length+')');}}).catch(function(){{setStatus('⚠️ Gagal simpan');}});}}
function setStatus(s){{var el=document.getElementById('saveStatus');if(el)el.textContent=s;}}
function togglePatient(h){{h.parentElement.classList.toggle('open');}}
function showVisit(t,p){{var c=t.closest('.patient-card');c.querySelectorAll('.visit-tab').forEach(x=>x.classList.remove('active'));c.querySelectorAll('.visit-panel').forEach(x=>x.classList.remove('active'));t.classList.add('active');var target=document.getElementById(p);if(target)target.classList.add('active');}}
function filterSearch(v){{if(typeof v==='string'&&v){{var q=v.toLowerCase();document.querySelectorAll('.patient-card').forEach(c=>c.style.display=c.textContent.toLowerCase().includes(q)?'block':'none');}}else{{document.querySelectorAll('.patient-card').forEach(c=>c.style.display='block');}}}}
function filterLoc(l){{document.querySelectorAll('.loc-section').forEach(function(s){{var t=s.querySelector('.loc-title').textContent;if(l==='all'){{s.style.display='block'}}else{{s.style.display=t.includes(l)?'block':'none'}}}});}}

function loadAll(norm,pid){{
  var btn=document.getElementById('btn-'+pid);
  if(btn)btn.textContent='Memuat...';
  fetch('/api/patient/'+norm).then(function(r){{return r.json();}}).then(function(d){{
    if(!d||!d.visits){{if(btn)btn.textContent='Gagal muat';return;}}
    var tabs=document.getElementById('tabs-'+pid);
    var card=tabs.closest('.patient-card');
    var body=card.querySelector('.patient-body');
    d.visits.forEach(function(v,vi){{
      if(vi<5)return;
      var tab=document.createElement('div');
      tab.className='visit-tab';
      tab.setAttribute('onclick',"showVisit(this,'h"+pid+"-"+vi+"')");
      var tgl=v.tgl?(v.tgl.length>=16?v.tgl.slice(0,16):v.tgl.slice(0,10)):'?';
      tab.innerHTML='Kunj '+(vi+1)+'<br><small>'+tgl+'</small>';
      tabs.insertBefore(tab,btn);
      
      var panel=document.createElement('div');
      panel.className='visit-panel';
      panel.id='h'+pid+'-'+vi;
      var html='<table><tr><th>Parameter</th><th>Hasil</th><th>N Normal</th><th>Satuan</th><th>Status</th></tr>';
      (v.params||[]).forEach(function(pv){{
        html+='<tr><td>'+(pv.name||'')+'</td><td>'+(pv.hasil||'')+'</td><td>'+(pv.normal||'')+'</td><td>'+(pv.satuan||'')+'</td><td></td></tr>';
      }});
      html+='</table>';
      panel.innerHTML=html;
      body.appendChild(panel);
    }});
    if(btn)btn.style.display='none';
  }}).catch(function(e){{if(btn)btn.textContent='Gagal muat';}});
}}

function toggleSpecial(btn,norm){{
  var box=btn.parentElement.querySelector('.special-result');
  if(box.style.display==='none'){{
    if(!box.dataset.loaded){{
      btn.textContent='Memuat...';
      fetch('/api/special/'+norm).then(r=>r.json()).then(function(d){{
        if(!d.success){{box.innerHTML='<div class="empty">'+d.error+'</div>';box.style.display='block';btn.textContent='📂 Sembunyikan';return;}}
        var h='';
        var secs={{'pa':'🔬 PA','rad':'📡 Radiologi','bmp':'🩸 BMP','lcs':'🧠 LCS','immuno':'🧬 Immunofenotyping','ihc':'🎯 IHC'}};
        for(var k in secs){{
          var arr=d[k]||[];
          if(!arr.length){{continue;}}
          h+='<div class="sp-section"><h4>'+secs[k]+' <span class="badge">'+arr.length+'</span></h4>';
          for(var i=0;i<arr.length;i++){{var x=arr[i];h+='<div class="sp-item">'+((x.tanggal||'?'))+' | '+((x.kesimpulan||x.kesan||x.jaringan||'(hasil)')+'')+'</div>';}}
          h+='</div>';
        }}
        if(!h)h='<div class="empty">Tidak ada data penunjang special di SIMRS</div>';
        box.innerHTML=h;box.dataset.loaded='1';
      }}).catch(function(e){{box.innerHTML='<div class="empty">Error: '+e+'</div>';}});
    }}
    box.style.display='block';btn.textContent='📂 Sembunyikan PA / Rad / BMP / LCS / Immuno / IHC';
  }}else{{box.style.display='none';btn.textContent='📂 Tampilkan PA / Rad / BMP / LCS / Immuno / IHC';}}
}}
document.addEventListener('keydown',function(e){{if(e.key==='/'&&!e.ctrlKey&&!e.metaKey){{e.preventDefault();document.getElementById('search').focus();}}}});
loadNotes();
</script>
</body></html>'''

out_path = f"/home/lenovo/Sync/Seno/Hermes-Outputs/Rekap Lab Hemato {len(patients)} Pasien - {today}.html"
with open(out_path, 'w') as f:
    f.write(html)
print(f"HTML generated: {out_path} ({len(patients)} patients)", flush=True)
