#!/usr/bin/env python3
"""Hemato notes server — serves report HTML + persistent notes API.
OPTIMIZED: in-memory cache + gzip + Cache-Control. Full lab data preserved.
"""
import json, os, gzip, threading, sys
from http.server import HTTPServer, SimpleHTTPRequestHandler
import pickle

OUT = '/home/lenovo/Sync/Seno/Hermes-Outputs'
NOTES_FILE = os.path.join(OUT, 'catatan_hemato.json')
PICKLE = '/tmp/simrs_15agustus_full.pkl'
FLAG_FILE = '/home/lenovo/.hermes/scripts/feature_flags.json'
PORT = 8788
sys.path.insert(0, '/home/lenovo/.hermes/scripts')

def lookup_enabled():
    try:
        return json.load(open(FLAG_FILE)).get('lookup_enabled', False)
    except Exception:
        return False

_html_cache = {'path': None, 'mtime': 0, 'data': None, 'lock': threading.Lock()}

def find_html():
    cands = []
    for fn in os.listdir(OUT):
        if fn.startswith('Rekap Lab Hemato') and fn.endswith('.html'):
            fp = os.path.join(OUT, fn)
            cands.append((os.path.getmtime(fp), fp))
    if not cands: return None
    cands.sort(reverse=True)
    return cands[0][1]

def get_cached_html():
    with _html_cache['lock']:
        path = find_html()
        if not path: return None
        mtime = os.path.getmtime(path)
        if _html_cache['path'] == path and _html_cache['mtime'] == mtime and _html_cache['data']:
            return _html_cache['data']
        with open(path, 'rb') as f:
            data = f.read()
        _html_cache['path'] = path
        _html_cache['mtime'] = mtime
        _html_cache['data'] = data
        return data

def get_patient_data(norm):
    """Return full lab data for a NORM from pickle with clustering support."""
    try:
        from datetime import datetime
        def cluster_labs(raw_groups):
            valid_groups = []
            for g in raw_groups:
                tgl_str = g.get('tgl', '')
                try:
                    dt = datetime.strptime(tgl_str[:19], '%Y-%m-%d %H:%M:%S')
                except:
                    try:
                        dt = datetime.strptime(tgl_str[:10], '%Y-%m-%d')
                    except:
                        dt = datetime.min
                valid_groups.append((dt, tgl_str, g.get('params', [])))
            valid_groups.sort(key=lambda x: x[0], reverse=True)

            clustered = []
            for dt, tgl_str, params in valid_groups:
                if not clustered:
                    clustered.append({'dt': dt, 'tgl': tgl_str, 'params': list(params)})
                    continue
                last = clustered[-1]
                same_day = (dt.date() == last['dt'].date()) if (dt != datetime.min and last['dt'] != datetime.min) else (tgl_str[:10] == last['tgl'][:10])
                time_diff = abs((last['dt'] - dt).total_seconds()) if (dt != datetime.min and last['dt'] != datetime.min) else 999999

                if same_day and time_diff <= 7200: # 2 hours
                    existing_names = {p.get('name', '').lower().strip() for p in last['params']}
                    for p in params:
                        pn = p.get('name', '').lower().strip()
                        if pn not in existing_names:
                            last['params'].append(p)
                            existing_names.add(pn)
                else:
                    clustered.append({'dt': dt, 'tgl': tgl_str, 'params': list(params)})
            return clustered

        if not os.path.exists(PICKLE): return None
        d = pickle.load(open(PICKLE, 'rb'))
        for k, v in d.items():
            if str(k).split('_')[0] == str(norm):
                raw_labs = v.get('labs') or v.get('visits') or []
                c_visits = cluster_labs(raw_labs)
                return {
                    'name': v.get('name'),
                    'visits': [{'tgl': vis.get('tgl'), 'params': vis.get('params', [])} for vis in c_visits]
                }
    except Exception as e:
        print(f"ERR get_patient_data: {e}")
        return None
    return None

class H(SimpleHTTPRequestHandler):
    def _send_gzip(self, data, ctype='text/html; charset=utf-8'):
        accept = self.headers.get('Accept-Encoding', '')
        if 'gzip' in accept and len(data) > 1024:
            compressed = gzip.compress(data)
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Encoding', 'gzip')
            self.send_header('Content-Length', str(len(compressed)))
            self.send_header('Cache-Control', 'public, max-age=30')
            self.end_headers()
            self.wfile.write(compressed)
        else:
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'public, max-age=30')
            self.end_headers()
            self.wfile.write(data)

    def do_GET(self):
        if self.path in ('/', '/index.html'):
            html = get_cached_html()
            if not html:
                self.send_response(404); self.end_headers(); return
            self._send_gzip(html)
        elif self.path in ('/lookup.html',):
            lpath = os.path.join(os.path.dirname(__file__), 'lookup.html')
            if not os.path.exists(lpath):
                self.send_response(404); self.end_headers(); return
            with open(lpath, 'rb') as f:
                self._send_gzip(f.read(), 'text/html; charset=utf-8')
        elif self.path in ('/special.html',):
            import glob
            files = sorted(glob.glob(os.path.join(OUT, 'PA-Rad-BMP Hemato * Pasien - *.html')), reverse=True)
            if not files:
                self.send_response(404); self.end_headers(); return
            with open(files[0], 'rb') as f:
                self._send_gzip(f.read(), 'text/html; charset=utf-8')
        elif self.path.startswith('/api/patient/'):
            norm = self.path.split('/')[-1]
            data = get_patient_data(norm)
            if not data:
                self.send_response(404); self.end_headers(); return
            body = json.dumps(data, ensure_ascii=False).encode()
            self._send_gzip(body, 'application/json; charset=utf-8')
        elif self.path.startswith('/api/lookup/'):
            if not lookup_enabled():
                self.send_response(403); self.send_header('Content-Type','application/json'); self.end_headers()
                self.wfile.write(b'{"success":false,"error":"Lookup disabled"}'); return
            norm = self.path.split('/')[-1]
            try:
                from hematology_lookup import lookup as do_lookup
                result = do_lookup(norm)
                body = json.dumps(result, ensure_ascii=False).encode()
                self._send_gzip(body, 'application/json; charset=utf-8')
            except Exception as e:
                self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers()
                self.wfile.write(json.dumps({'success':False,'error':f'Server error: {type(e).__name__}'},ensure_ascii=False).encode())
        elif self.path.startswith('/api/special/'):
            # Return PA/Rad/BMP/LCS/Immuno/IHC for a NORM (from pre-fetched pickle)
            norm = self.path.split('/')[-1]
            try:
                import pickle as _pk
                PKL='/tmp/simrs_special_15agustus.pkl'
                if not os.path.exists(PKL):
                    raise Exception('Pickle not found - run fetch first')
                data=_pk.load(open(PKL,'rb'))
                v=data.get(norm)
                if not v:
                    raise Exception('NORM not in list')
                result={'success':True,'norm':norm,'name':v.get('name'),
                        'pa':v.get('pa',[]),'rad':v.get('rad',[]),'bmp':v.get('bmp',[]),
                        'lcs':v.get('lcs',[]),'immuno':v.get('immuno',[]),'ihc':v.get('ihc',[])}
                body=json.dumps(result,ensure_ascii=False).encode()
                self._send_gzip(body,'application/json; charset=utf-8')
            except Exception as e:
                self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers()
                self.wfile.write(json.dumps({'success':False,'error':f'Server error: {type(e).__name__}'},ensure_ascii=False).encode())
        elif self.path.startswith('/api/notes'):
            notes = {}
            if os.path.exists(NOTES_FILE):
                try: notes = json.load(open(NOTES_FILE))
                except Exception: notes = {}
            body = json.dumps(notes, ensure_ascii=False).encode()
            self._send_gzip(body, 'application/json; charset=utf-8')
        else:
            super().do_GET()

    def do_POST(self):
        if self.path.startswith('/api/notes'):
            ln = int(self.headers.get('Content-Length', 0) or 0)
            raw = self.rfile.read(ln).decode() if ln else '{}'
            try: notes = json.loads(raw)
            except Exception: notes = {}
            with open(NOTES_FILE, 'w') as f:
                json.dump(notes, f, ensure_ascii=False, indent=1)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(b'{"ok":true}')
        else:
            self.send_response(404); self.end_headers()

    def log_message(self, *a):
        pass

if __name__ == '__main__':
    print(f"Hemato notes server on :{PORT} (gzip+cache enabled)", flush=True)
    HTTPServer(('0.0.0.0', PORT), H).serve_forever()
